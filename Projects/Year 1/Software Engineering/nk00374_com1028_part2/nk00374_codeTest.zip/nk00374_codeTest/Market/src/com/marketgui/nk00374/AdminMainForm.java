/**
 * AdminMainForm.java
 */
package com.marketgui.nk00374;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.Admin;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.GroupType;
import com.market.nk00374.Product;
import com.market.nk00374.ProductType;

import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.SystemColor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JScrollPane;
/**
 * 
 * Admin form
 * 
 * @author Nithesh Koneswaran
 *
 */
public class AdminMainForm extends JFrame {
	private JPanel contentPane;
	/** Declaring components as fields so that they can be accessed in the method and outside the constructor*/
	/** JLabel holds a user's fullname */
	private JLabel txtFullName;
	/** JLabel holds a user's username */
	private JLabel lblUsername;
	/** JLabel holds a user's birthday */
	private JLabel txtBirthday;
	/** JLabel holds a user's email */
	private JLabel txtEmail;
	/** JLabel holds a user's telephone */
	private JLabel txtTelephone;
	/** JLabel holds a user's balance */
	private JLabel txtBalance;
	/** JLabel holds the value BANNED or UNBANNED for a user */
	private JLabel txtGroup;
	/** JButton when clicked will remove the selected product*/
	private JButton btnRemoveProduct;
	/** JButton when clicked will unverify the selected product*/
	private JButton btnUnverify;
	/** JButton when clicked will verify the selected product*/
	private JButton btnVerify;
	/** JTextArea holds the products details */
	private JTextArea txtDetails;
	/** JTextArea holds the products reviews */
	private JTextArea txtReviews;
	/** JLabel holds a product's price */
	private JLabel txtPrice;
	/** JLabel holds a product's rating */
	private JLabel txtRating;
	/** JLabel holds a product's stock */
	private JLabel txtStock;
	/** JLabel holds a product's category type */
	private JLabel txtCategory;
	/** JLabel holds a product's seller */
	private JLabel txtSeller;
	/** JComboBox can refine the product list */
	private JComboBox cbRefine;
	/** JButton when clicked will ban the selected User*/
	private JButton btnBanUser;
	/** JButton when clicked will unban the selected User*/
	private JButton btnUnbanUser;
	/** JList holds the list of users*/
	private JList<String> list;
	/** JList holds the list of products */
	private JList<String> listProducts;
	/** Id format */
	private DecimalFormat id;
	/** Currency format */
	private DecimalFormat currency;
	/** Holds the list of customers */
	private List<Customer> customers;
	/** Holds the list of products */
	private List<Product> products;
	/** The currently logged in admin */
	private Admin admin;
	/** JTextArea Holds all the logs */
	private JTextArea txtLogs;
	/** Allows scrolling movement */
	private JScrollPane scrollPane;
	

	/**
	 * Create the frame.
	 */
	public AdminMainForm() throws NullPointerException {

		this.admin = CurrentSession.getInstance().getAdmin();
		this.currency = new DecimalFormat("#0.00");
		this.id = new DecimalFormat("#0000");
		if (this.admin==null) {
			throw new NullPointerException("Admin cannot be empty!");
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 755, 536);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(Color.BLACK);
		panel.setBackground(new Color(40, 50, 64));
		panel.setBounds(0, 0, 739, 55);
		this.contentPane.add(panel);

		JLabel lblAdminControlCenter = new JLabel("Admin Control Center");
		lblAdminControlCenter.setForeground(new Color(222, 209, 63));
		lblAdminControlCenter.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblAdminControlCenter.setBackground(Color.WHITE);
		lblAdminControlCenter.setBounds(21, 11, 331, 22);
		panel.add(lblAdminControlCenter);

		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CurrentSession.getInstance().logout();
				new LoginForm();
				dispose();
			}
		});
		btnLogOut.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnLogOut.setEnabled(true);
		btnLogOut.setBounds(635, 10, 94, 29);
		panel.add(btnLogOut);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);

		tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		tabbedPane.setBounds(0, 56, 739, 441);
		this.contentPane.add(tabbedPane);

		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Users", null, panel_1, null);
		panel_1.setLayout(null);

		this.list = new JList<String>();

		this.list.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				String[] parts = list.getSelectedValue().split(" \\| ");
				int id = Integer.parseInt(parts[0]);

				if (list.getSelectedIndex() != -1) {
					for (Customer customer : customers) {
						if (customer.getUserID() == id) {
							SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
							txtFullName.setText(customer.getFullName());
							lblUsername.setText(customer.getUsername());
							txtBirthday.setText(format.format(customer.getBirthday()));
							txtEmail.setText(customer.getEmail());
							txtTelephone.setText(customer.getTelephone());
							txtBalance.setText("�" + currency.format(customer.getBalance()));
							txtGroup.setText(customer.getGroup().toString());

							if (customer.getGroup().equals(GroupType.BANNED)) {
								btnBanUser.setEnabled(false);
								btnUnbanUser.setEnabled(true);
							}

							if (customer.getGroup().equals(GroupType.UNBANNED)) {
								btnBanUser.setEnabled(true);
								btnUnbanUser.setEnabled(false);
							}

						}
					}
				}

			}
		});

		this.list.setSelectedIndex(0);
		this.list.setLayoutOrientation(JList.VERTICAL_WRAP);
		this.list.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.list.setBackground(SystemColor.menu);
		this.list.setBounds(10, 10, 230, 385);
		panel_1.add(this.list);

		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBackground(new Color(40, 50, 64));
		separator.setBounds(250, 10, 21, 374);
		panel_1.add(separator);

		this.lblUsername = new JLabel("Username");
		this.lblUsername.setForeground(Color.BLACK);
		this.lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		this.lblUsername.setBackground(Color.WHITE);
		this.lblUsername.setBounds(267, -6, 385, 48);
		panel_1.add(this.lblUsername);

		JLabel lblName = new JLabel("Name  :");
		lblName.setForeground(Color.BLACK);
		lblName.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblName.setBackground(Color.WHITE);
		lblName.setBounds(267, 36, 55, 22);
		panel_1.add(lblName);

		JLabel lblBirthday = new JLabel("Birthday :");
		lblBirthday.setForeground(Color.BLACK);
		lblBirthday.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblBirthday.setBackground(Color.WHITE);
		lblBirthday.setBounds(267, 69, 74, 22);
		panel_1.add(lblBirthday);

		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setForeground(Color.BLACK);
		lblEmail.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblEmail.setBackground(Color.WHITE);
		lblEmail.setBounds(267, 102, 74, 22);
		panel_1.add(lblEmail);

		JLabel lblTelephone = new JLabel("Telephone :");
		lblTelephone.setForeground(Color.BLACK);
		lblTelephone.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblTelephone.setBackground(Color.WHITE);
		lblTelephone.setBounds(267, 135, 74, 22);
		panel_1.add(lblTelephone);

		JLabel lblBalance = new JLabel("Balance :");
		lblBalance.setForeground(Color.BLACK);
		lblBalance.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblBalance.setBackground(Color.WHITE);
		lblBalance.setBounds(267, 168, 55, 22);
		panel_1.add(lblBalance);

		JLabel lblGrouptype = new JLabel("Group Type :");
		lblGrouptype.setForeground(Color.BLACK);
		lblGrouptype.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblGrouptype.setBackground(Color.WHITE);
		lblGrouptype.setBounds(267, 201, 89, 22);
		panel_1.add(lblGrouptype);

		this.btnUnbanUser = new JButton("Unban User");
		this.btnUnbanUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] parts = list.getSelectedValue().split(" \\| ");
				int id = Integer.parseInt(parts[0]);
				for (Customer customer : customers) {
					if (customer.getUserID() == id) {
						if (customer.getGroup().equals(GroupType.BANNED)) {
							customer.setGroup(GroupType.UNBANNED);
							btnBanUser.setEnabled(true);
							btnUnbanUser.setEnabled(false);
							txtGroup.setText(customer.getGroup().toString());
							admin.addLog(admin.getUsername()+ " has unbanned user " + customer.getUsername() +":"+customer.getUserID());

						}
					}
				}
				 refreshLog();
			}
		});
		this.btnUnbanUser.setEnabled(false);
		this.btnUnbanUser.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		this.btnUnbanUser.setBounds(585, 355, 139, 29);
		panel_1.add(this.btnUnbanUser);

		this.btnBanUser = new JButton("Ban User");
		this.btnBanUser.setEnabled(false);
		this.btnBanUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] parts = list.getSelectedValue().split(" \\| ");
				int id = Integer.parseInt(parts[0]);
				for (Customer customer : customers) {
					if (customer.getUserID() == id) {
						if (customer.getGroup().equals(GroupType.UNBANNED)) {
							customer.setGroup(GroupType.BANNED);
							btnBanUser.setEnabled(false);
							btnUnbanUser.setEnabled(true);
							txtGroup.setText(customer.getGroup().toString());
							admin.addLog(admin.getUsername()+ " has banned user " + customer.getUsername() +":"+customer.getUserID());	
						}
					}
					 refreshLog();
				}

			}
		});
		this.btnBanUser.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		this.btnBanUser.setBounds(585, 319, 139, 29);
		panel_1.add(this.btnBanUser);

		this.txtFullName = new JLabel("---------");
		this.txtFullName.setForeground(Color.BLACK);
		this.txtFullName.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtFullName.setBackground(Color.WHITE);
		this.txtFullName.setBounds(328, 36, 348, 22);
		panel_1.add(this.txtFullName);

		this.txtBirthday = new JLabel("---------");
		this.txtBirthday.setForeground(Color.BLACK);
		this.txtBirthday.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtBirthday.setBackground(Color.WHITE);
		this.txtBirthday.setBounds(325, 69, 368, 22);
		panel_1.add(this.txtBirthday);

		this.txtEmail = new JLabel("---------");
		this.txtEmail.setForeground(Color.BLACK);
		this.txtEmail.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtEmail.setBackground(Color.WHITE);
		this.txtEmail.setBounds(314, 102, 358, 22);
		panel_1.add(this.txtEmail);

		this.txtTelephone = new JLabel("---------");
		this.txtTelephone.setForeground(Color.BLACK);
		this.txtTelephone.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtTelephone.setBackground(Color.WHITE);
		this.txtTelephone.setBounds(348, 135, 328, 22);
		panel_1.add(this.txtTelephone);

		this.txtBalance = new JLabel("---------");
		this.txtBalance.setForeground(Color.BLACK);
		this.txtBalance.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtBalance.setBackground(Color.WHITE);
		this.txtBalance.setBounds(332, 168, 344, 22);
		panel_1.add(this.txtBalance);

		this.txtGroup = new JLabel("---------");
		this.txtGroup.setForeground(Color.BLACK);
		this.txtGroup.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtGroup.setBackground(Color.WHITE);
		this.txtGroup.setBounds(357, 201, 294, 22);
		panel_1.add(this.txtGroup);

		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Products", null, panel_2, null);
		panel_2.setLayout(null);

		this.listProducts = new JList<String>();
		this.listProducts.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				if (listProducts.getSelectedIndex() != -1) {
					String[] parts = listProducts.getSelectedValue().split(" \\| ");
					int id = Integer.parseInt(parts[0]);

					for (Product product : products) {
						if (product.getProductID() == id) {

							txtDetails.setText(product.getDescription());
							txtReviews.setText(product.reviewToString());
							txtPrice.setText("�" + currency.format(product.getPrice()));
							txtRating.setText(String.valueOf(product.getRating()));
							txtStock.setText(String.valueOf(product.getStock()));
							txtCategory.setText(product.getCategory().toString());
							txtSeller.setText(product.getSeller().getUsername());

							if (product.getType().equals(ProductType.VERIFIED)) {
								btnUnverify.setEnabled(true);
								btnVerify.setEnabled(false);
							}

							if (product.getType().equals(ProductType.NONVERIFIED)) {
								btnVerify.setEnabled(true);
								btnUnverify.setEnabled(false);
							}
						}
					}

					btnRemoveProduct.setEnabled(true);
				}

			}
		});

		this.listProducts.setSelectedIndex(0);
		this.listProducts.setLayoutOrientation(JList.VERTICAL_WRAP);
		this.listProducts.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.listProducts.setBackground(SystemColor.menu);
		this.listProducts.setBounds(10, 10, 230, 345);
		panel_2.add(this.listProducts);

		JSeparator separator_1 = new JSeparator();
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBackground(new Color(40, 50, 64));
		separator_1.setBounds(250, 10, 21, 385);
		panel_2.add(separator_1);

		this.btnRemoveProduct = new JButton("Delete");
		this.btnRemoveProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedOption = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to remove this Product?", "", JOptionPane.YES_NO_OPTION);
				if (selectedOption == JOptionPane.YES_OPTION) {
					String[] parts = listProducts.getSelectedValue().split(" \\| ");
					int id = Integer.parseInt(parts[0]);
					for (Product product : products) {
						if (product.getProductID() == id) {
							if (product.deleteProduct()) {
								loadProducts();
								admin.addLog(admin.getUsername()+ " has deleted product " + product.getTitle() +":"+product.getProductID());
							}
						}
					}
					
					 refreshLog();
				}
				

			}
		});
		this.btnRemoveProduct.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		this.btnRemoveProduct.setEnabled(false);
		this.btnRemoveProduct.setBounds(619, 8, 105, 29);
		panel_2.add(this.btnRemoveProduct);

		this.btnUnverify = new JButton("Unverify");
		this.btnUnverify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (listProducts.getSelectedIndex() != -1) {
					String[] parts = listProducts.getSelectedValue().split(" \\| ");
					int id = Integer.parseInt(parts[0]);
					for (Product product : products) {
						if (product.getProductID() == id) {
							product.setType(ProductType.NONVERIFIED);
							admin.addLog(admin.getUsername()+ " changed the product type of " + product.getTitle() +" to unverified");

						}
					}
					loadProducts();
					btnUnverify.setEnabled(false);
					btnVerify.setEnabled(false);
					listProducts.setSelectedIndex(-1);
					 refreshLog();
				}
			}
		});
		this.btnUnverify.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		this.btnUnverify.setEnabled(false);
		this.btnUnverify.setBounds(619, 42, 105, 29);
		panel_2.add(this.btnUnverify);

		this.btnVerify = new JButton("Verify");
		this.btnVerify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (listProducts.getSelectedIndex() != -1) {
					String[] parts = listProducts.getSelectedValue().split(" \\| ");
					int id = Integer.parseInt(parts[0]);
					for (Product product : products) {
						if (product.getProductID() == id) {
							product.setType(ProductType.VERIFIED);
							admin.addLog(admin.getUsername()+ " changed the product type of " + product.getTitle() +" to verified");

						}
					}
					loadProducts();
					btnUnverify.setEnabled(false);
					btnVerify.setEnabled(false);
					listProducts.setSelectedIndex(-1);
					 refreshLog();
				}
			}
		});
		this.btnVerify.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		this.btnVerify.setEnabled(false);
		this.btnVerify.setBounds(619, 79, 105, 29);
		panel_2.add(this.btnVerify);

		this.cbRefine = new JComboBox();
		this.cbRefine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadProducts();
				btnUnverify.setEnabled(false);
				btnVerify.setEnabled(false);
				listProducts.setSelectedIndex(-1);
			}
		});

		this.cbRefine.setModel(new DefaultComboBoxModel(
				new String[] { "All Products", "Verified Products", "Non-Verified Products" }));
		this.cbRefine.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.cbRefine.setBounds(10, 366, 230, 29);
		panel_2.add(this.cbRefine);

		JLabel lblProductTitle = new JLabel("Product Title");
		lblProductTitle.setForeground(Color.BLACK);
		lblProductTitle.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblProductTitle.setBackground(Color.WHITE);
		lblProductTitle.setBounds(261, 10, 340, 34);
		panel_2.add(lblProductTitle);

		JLabel label = new JLabel("Price  :");
		label.setForeground(Color.BLACK);
		label.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		label.setBackground(Color.WHITE);
		label.setBounds(261, 46, 55, 22);
		panel_2.add(label);

		JLabel label_1 = new JLabel("Rating :");
		label_1.setForeground(Color.BLACK);
		label_1.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		label_1.setBackground(Color.WHITE);
		label_1.setBounds(261, 79, 55, 22);
		panel_2.add(label_1);

		JLabel label_2 = new JLabel("Stock  :");
		label_2.setForeground(Color.BLACK);
		label_2.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		label_2.setBackground(Color.WHITE);
		label_2.setBounds(261, 112, 55, 22);
		panel_2.add(label_2);

		JLabel label_3 = new JLabel("Category: ");
		label_3.setForeground(Color.BLACK);
		label_3.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		label_3.setBackground(Color.WHITE);
		label_3.setBounds(261, 142, 69, 22);
		panel_2.add(label_3);

		this.txtDetails = new JTextArea();
		this.txtDetails.setLineWrap(true);
		this.txtDetails.setForeground(Color.BLACK);
		this.txtDetails.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtDetails.setEditable(false);
		this.txtDetails.setBackground(SystemColor.menu);
		this.txtDetails.setBounds(261, 170, 463, 87);
		panel_2.add(this.txtDetails);

		this.txtReviews = new JTextArea();
		this.txtReviews.setLineWrap(true);
		this.txtReviews.setForeground(Color.BLACK);
		this.txtReviews.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtReviews.setEditable(false);
		this.txtReviews.setBackground(SystemColor.menu);
		this.txtReviews.setBounds(260, 284, 464, 112);
		panel_2.add(this.txtReviews);

		JLabel lblReviews = new JLabel("Reviews:");
		lblReviews.setForeground(Color.BLACK);
		lblReviews.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblReviews.setBackground(Color.WHITE);
		lblReviews.setBounds(261, 263, 69, 22);
		panel_2.add(lblReviews);

		this.txtPrice = new JLabel("");
		this.txtPrice.setForeground(Color.BLACK);
		this.txtPrice.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtPrice.setBackground(Color.WHITE);
		this.txtPrice.setBounds(312, 49, 116, 22);
		panel_2.add(this.txtPrice);

		this.txtRating = new JLabel("");
		this.txtRating.setForeground(Color.BLACK);
		this.txtRating.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtRating.setBackground(Color.WHITE);
		this.txtRating.setBounds(312, 79, 116, 22);
		panel_2.add(this.txtRating);

		this.txtStock = new JLabel("");
		this.txtStock.setForeground(Color.BLACK);
		this.txtStock.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtStock.setBackground(Color.WHITE);
		this.txtStock.setBounds(312, 112, 116, 22);
		panel_2.add(this.txtStock);

		this.txtCategory = new JLabel("");
		this.txtCategory.setForeground(Color.BLACK);
		this.txtCategory.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtCategory.setBackground(Color.WHITE);
		this.txtCategory.setBounds(322, 142, 178, 22);
		panel_2.add(this.txtCategory);

		JLabel lblSeller = new JLabel("Seller:");
		lblSeller.setForeground(Color.BLACK);
		lblSeller.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblSeller.setBackground(Color.WHITE);
		lblSeller.setBounds(508, 142, 69, 22);
		panel_2.add(lblSeller);

		this.txtSeller = new JLabel("");
		this.txtSeller.setForeground(Color.BLACK);
		this.txtSeller.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtSeller.setBackground(Color.WHITE);
		this.txtSeller.setBounds(552, 142, 172, 22);
		panel_2.add(this.txtSeller);

		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Log", null, panel_3, null);
		panel_3.setLayout(null);
		
		this.scrollPane = new JScrollPane();
		this.scrollPane.setViewportBorder(null);
		this.scrollPane.setBorder(null);
		this.scrollPane.setBounds(10, 10, 714, 385);
		panel_3.add(this.scrollPane);
		
		this.txtLogs = new JTextArea();
		this.scrollPane.setViewportView(txtLogs);
		this.txtLogs.setLineWrap(true);
		this.txtLogs.setForeground(Color.BLACK);
		this.txtLogs.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtLogs.setEditable(false);
		this.txtLogs.setBackground(SystemColor.menu);

		
		loadUsers();
		loadProducts();
		refreshLog();
	}

	private static class __Tmp {
		private static void __tmp() {
			javax.swing.JPanel __wbp_panel = new javax.swing.JPanel();
		}
	}
	
	public void refreshLog() {
		txtLogs.setText(admin.loadLogs());
	}

	public void loadUsers() {
		Connection connect = DBConnection.connect();
		String query = "SELECT * FROM Customer";
		PreparedStatement pst = null;
		ResultSet rs = null;
		this.customers = new ArrayList<>();

		DefaultListModel<String> model = new DefaultListModel<String>();
		try {
			pst = connect.prepareStatement(query);
			rs = pst.executeQuery();
			while (rs.next()) {
				Customer customer = new Customer(rs.getInt("User_ID"));
				this.customers.add(customer);
				model.addElement(this.id.format(customer.getUserID()) + " | " + customer.getFullName());
			}
			this.list.setModel(model);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void loadProducts() {
		Connection connect = DBConnection.connect();
		StringBuffer query = new StringBuffer("SELECT * FROM Product");

		if (this.cbRefine.getSelectedIndex() == 1) {
			query.append(" WHERE Verified=1");
		}

		if (this.cbRefine.getSelectedIndex() == 2) {
			query.append(" WHERE Verified=0");
		}

		PreparedStatement pst = null;
		ResultSet rs = null;
		this.products = new ArrayList<>();
		DefaultListModel<String> model = new DefaultListModel<String>();
		try {
			pst = connect.prepareStatement(query.toString());
			rs = pst.executeQuery();
			while (rs.next()) {
				Product product = new Product(rs.getInt("Product_ID"));
				this.products.add(product);
				model.addElement(this.id.format(product.getProductID()) + " | " + product.getTitle() + " | �"
						+ this.currency.format(product.getPrice()));
			}
			this.listProducts.setModel(model);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}
}
