/**
 * EditProduct.java
 */
package com.marketgui.nk00374;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.connection.nk00374.DBConnection;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Button;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import com.connection.nk00374.DBConnection;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.Product;
import com.market.nk00374.ProductCategory;
/**
 * @author Nithesh Koneswaran
 *
 */
public class EditProduct extends JFrame {
	private JPanel contentPane;
	/** Input for product title */
	private JTextField txtTitle;
	/** Input for product details */
	private JTextField txtDetails;
	/** Input for product Stock */
	private JTextField txtStock;
	/** Input for product Cost */
	private JTextField txtCost;
	/** Input for any restriction for product */
	private JComboBox cbRestriction;
	/** Input for product category */
	private JComboBox cbCategory ;
	/** The currently logged in user */
	private Customer customer;
	/** Error messages to be created if the edit goes wrong */
	private StringBuffer emessage;
	/** Regex for price and stock */
	private final static String MONEY = "[0-9]+([.]{1}[0-9]{0,2})|[0-9]+";
	private final static String NUMBERS = "\\d+";
	private Product product;

	/** sets the instance of the edit product form to null*/
	private static EditProduct obj = null;
	
	/**
	 * @param productID
	 * 			This will be the product the user will be editing
	 * @returns the instance of the edit product form if it does not exist already
	 */
	public static EditProduct getObj(int productID) {
		if (obj==null) {
			obj = new EditProduct(productID);
		} else {
			obj.dispose();
			obj = new EditProduct(productID);
		}
		return obj;
	}
	
	/**
	 * Create the frame.
	 */
	private EditProduct(int productID) throws IllegalArgumentException, NullPointerException {
		if (productID<0) {
			throw new IllegalArgumentException("ID cannot be less than 0!");
		}
		product = new Product(productID);
		customer = CurrentSession.getInstance().getCustomer();
		if (customer==null) {
			throw new NullPointerException("Customer cannot be null!");
		}
		
		
		emessage = new StringBuffer("Failed to add product: \n");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 370, 426);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(Color.BLACK);
		panel.setBackground(new Color(40, 50, 64));
		panel.setBounds(0, 0, 605, 53);
		contentPane.add(panel);
		
		JLabel lblUploadAProduct = new JLabel("Edit product");
		lblUploadAProduct.setForeground(new Color(222, 209, 63));
		lblUploadAProduct.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblUploadAProduct.setBackground(Color.WHITE);
		lblUploadAProduct.setBounds(21, 11, 232, 31);
		panel.add(lblUploadAProduct);
		
		txtTitle = new JTextField();
		txtTitle.setText(product.getTitle());
		txtTitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		txtTitle.setColumns(10);
		txtTitle.setBounds(10, 85, 334, 25);
		contentPane.add(txtTitle);
		
		JLabel lblProductTitle = new JLabel("Title");
		lblProductTitle.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblProductTitle.setBounds(10, 63, 123, 22);
		contentPane.add(lblProductTitle);
		
		JLabel lblDetails = new JLabel("Details");
		lblDetails.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblDetails.setBounds(10, 230, 123, 22);
		contentPane.add(lblDetails);
		
		txtDetails = new JTextField();
		txtDetails.setText(product.getDescription());
		txtDetails.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		txtDetails.setColumns(10);
		txtDetails.setBounds(10, 254, 334, 80);
		contentPane.add(txtDetails);
		
		JLabel lblStock = new JLabel("Stock");
		lblStock.setHorizontalAlignment(SwingConstants.CENTER);
		lblStock.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblStock.setBounds(10, 113, 99, 25);
		contentPane.add(lblStock);
		
		txtStock = new JTextField();
		txtStock.setText(String.valueOf(product.getInitialStock()));
		txtStock.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		txtStock.setColumns(10);
		txtStock.setBounds(12, 140, 97, 25);
		contentPane.add(txtStock);
		
		JLabel lblCost = new JLabel("Cost");
		lblCost.setHorizontalAlignment(SwingConstants.CENTER);
		lblCost.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblCost.setBounds(119, 108, 103, 34);
		contentPane.add(lblCost);
		
		txtCost = new JTextField();
		txtCost.setText(String.valueOf(product.getPrice()));
		txtCost.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		txtCost.setColumns(10);
		txtCost.setBounds(119, 140, 103, 25);
		contentPane.add(txtCost);
		
		JLabel lblAgeRestriction = new JLabel("Age Restriction");
		lblAgeRestriction.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblAgeRestriction.setBounds(233, 114, 111, 22);
		contentPane.add(lblAgeRestriction);
		
		cbRestriction = new JComboBox();
		cbRestriction.setSelectedItem(product.getAgeRestriction());
		cbRestriction.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		cbRestriction.setModel(new DefaultComboBoxModel(new String[] {"None", "18+", "21+"}));
		cbRestriction.setBounds(232, 140, 112, 25);
		contentPane.add(cbRestriction);
		
		cbCategory = new JComboBox();
		cbCategory.setSelectedItem(product.getCategory().toString());
		cbCategory.setModel(new DefaultComboBoxModel(ProductCategory.values()));
		cbCategory.removeItemAt(0);
		cbCategory.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		cbCategory.setBounds(10, 194, 334, 25);
		contentPane.add(cbCategory);
		
		JLabel lblCategory = new JLabel("Category");
		lblCategory.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblCategory.setBounds(10, 169, 111, 22);
		contentPane.add(lblCategory);
		
		/**
		 * Updates the product
		 */
		JButton btnSubmit = new JButton("Update");
		btnSubmit.setBounds(10, 345, 334, 29);
		contentPane.add(btnSubmit);
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (validation()) {
					int selectedOption = JOptionPane.showConfirmDialog(null, "Note: the amount sold will be wiped!!"," Would you like to proceed?",
							JOptionPane.YES_NO_OPTION);
					if (selectedOption == JOptionPane.YES_OPTION) {
						editProduct(productID);
					}
				} else {
					JOptionPane.showMessageDialog(null, emessage.toString());
				}
			}
		});
		btnSubmit.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				dispose();
			}

		});
		
	}
	
	/**
	 * @return true if the validation passes
	 * 			false if the validation fails
	 */
	public boolean validation() {
		emessage = new StringBuffer("Failed to edit product: \n");
		boolean valid = true;
		if (txtTitle.getText().isEmpty() || txtStock.getText().isEmpty() || txtCost.getText().isEmpty() || txtDetails.getText().isEmpty() ) {
			emessage.append("Please fill any blank fields \n");
			valid = false;
		}

		if (!txtCost.getText().matches(MONEY)) {
			emessage.append("invalid price \n");
			valid = false;
		}
		
		if (!txtStock.getText().matches(NUMBERS)) {
			emessage.append("invalid stock \n");
			valid = false;
		}	

			return valid;
	}
	
	/**
	 * @param productID
	 * 			The product that will have its details changed
	 */
	public void editProduct(int productID) {
		Connection connect = DBConnection.connect();
		boolean errors = false;
		int age = 0;
		
		if (cbRestriction.getSelectedIndex()==0) {
			age = 0;
		}
		if (cbRestriction.getSelectedIndex()==1) {
			age = 18;
		}
		if (cbRestriction.getSelectedIndex()==2) {
			age = 21;
		}
		String query = null;
		PreparedStatement pst = null;
		try {
			query = "UPDATE Product SET Name=?, Details=?, Initial_Stock=?, Current_Stock=?, Cost=?, AgeRestriction=?, Category=? WHERE Product_ID=?";
			pst = connect.prepareStatement(query);
			pst.setString(1, txtTitle.getText());
			pst.setString(2, txtDetails.getText());
			pst.setInt(3, Integer.parseInt(txtStock.getText()));
			pst.setInt(4, Integer.parseInt(txtStock.getText()));
			pst.setDouble(5, Double.parseDouble(txtCost.getText()));
			pst.setInt(6, age);
			pst.setString(7, cbCategory.getSelectedItem().toString());
			pst.setInt(8, productID);
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "Product Updated!!!");
		} catch (Exception e) {
			errors = true;
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					errors = true;
					e.printStackTrace();
				}
			}
		}

		if (errors) {
			JOptionPane.showMessageDialog(null, "Error Occured");
		}  else {
			customer.initialise();
			MyProductsForm.getObj().setVisible(true);
			dispose();
		}
		
		
	}
	
}
