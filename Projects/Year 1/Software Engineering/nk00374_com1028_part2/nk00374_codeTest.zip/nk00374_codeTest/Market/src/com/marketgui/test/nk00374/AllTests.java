/**
 * AllTests.java
 */
package com.marketgui.test.nk00374;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
/**
 * @author Nithesh Koneswaran
 *
 *
 *  Runs all the tests
 */

@RunWith(Suite.class)
@SuiteClasses({ AddNewProductTest.class,  AddReviewFormTest.class, AdminMainFormTest.class, BasketFormTest.class, CustomerProfileTest.class, EditProductTest.class,
	LoginFormTest.class, MainPageTest.class, MyProductsFormTest.class, RegisterFormTest.class, TransactionFormTest.class, WishlistFormTest.class})
public class AllTests {
}