/**
 * ProductCategory.java
 */
package com.market.nk00374;
/**
 * An Enumeration class that tags a product with a category
 * 
 * @author Nithesh Koneswaran
 *
 */
public enum ProductCategory {
	ALL, CLOTHING, ACCESSORIES, BOOKS, JEWELRY, DVD, MUSIC, GAMES, ELECTRONICS, STATIONARY, PETS, OTHER
}
