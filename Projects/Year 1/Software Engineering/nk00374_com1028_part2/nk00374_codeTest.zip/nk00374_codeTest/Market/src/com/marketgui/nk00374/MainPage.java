/**
 * MainPage.java
 */
package com.marketgui.nk00374;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.connection.nk00374.DBConnection;

import java.awt.Color;
import java.awt.Font;
import java.awt.List;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.*;

import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.Product;
import com.market.nk00374.ProductCategory;
/**
 * @author Nithesh Koneswaran
 *
 */
public class MainPage extends JFrame {
	private JPanel contentPane;
	/** Input which allows the user to search for a product */
	private JTextField txtSearchForProduct;
	/** Displays the list of products in a JList */
	private JList<String> listProducts;
	/** Provides a connection to the database */
	private Connection connect;
	/** Matches the product title with the product ID*/
	private Map<String, Integer> productID;
	/** The rating of a selcted product */
	private JLabel lblVariableRating;
	/** refine the list of products by the categories*/
	private JComboBox<?> cbSearchBy;
	/** regine the list of products by further options */
	private JComboBox cbRefineBy;
	/** The selected quantity the user would like to add to the basket */
	private JTextField txtSelectQuantity;
	/** The list of reviews of a selected review */
	private JTextArea lblListOfReviews;
	/** The currently logged in customer */
	private Customer customer;
	/** Refers to the instance of the MainPage */
	private static MainPage frame;
	/** Formats the product's ID to #0000 */
	private DecimalFormat id;
	/** Formats the products cost */
	private DecimalFormat cost;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new MainPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainPage() throws NullPointerException {
		this.id = new DecimalFormat("#0000");
		this.cost = new DecimalFormat("#0.00");

		this.customer = CurrentSession.getInstance().getCustomer();
		if (this.customer==null) {
			throw new NullPointerException("Customer cannot be null!");
		}
		
		String fullName = this.customer.getFullName();

		this.productID = new HashMap<>();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 976, 713);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(40, 50, 64));
		panel.setForeground(Color.BLACK);
		panel.setBounds(0, 0, 960, 94);
		this.contentPane.add(panel);
		panel.setLayout(null);

		/**
		 * Whenever the selection is changed the list of products in the JList is refreshed
		 */
		this.cbSearchBy = new JComboBox();
		this.cbSearchBy.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				loadProducts();
			}
		});
		
		this.cbSearchBy.setModel(new DefaultComboBoxModel(ProductCategory.values()));
		this.cbSearchBy.setSelectedIndex(0);
		this.cbSearchBy.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.cbSearchBy.setBounds(725, 53, 206, 29);
		panel.add(this.cbSearchBy);

		JLabel lblNewLabel = new JLabel("Hello");
		lblNewLabel.setForeground(new Color(222, 209, 63));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblNewLabel.setBounds(21, 11, 116, 22);
		panel.add(lblNewLabel);

		if (!fullName.isEmpty()) {
			JLabel lblFullname = new JLabel(fullName);
			lblFullname.setForeground(Color.WHITE);
			lblFullname.setFont(new Font("Segoe UI Light", Font.BOLD, 25));
			lblFullname.setBackground(Color.WHITE);
			lblFullname.setBounds(89, 0, 385, 45);
			panel.add(lblFullname);
		}

		this.txtSearchForProduct = new JTextField();
		this.txtSearchForProduct.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void changedUpdate(DocumentEvent arg0) {
				update();
			}

			@Override
			public void insertUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				update();
			}

			@Override
			public void removeUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				update();
			}

			public void update() {
				if (txtSearchForProduct.getText().isEmpty()) {
					loadProducts();
				} else {
					searchProducts();
				}
			}
		});
		this.txtSearchForProduct.setToolTipText("");
		this.txtSearchForProduct.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.txtSearchForProduct.setBounds(23, 53, 692, 29);
		panel.add(this.txtSearchForProduct);
		this.txtSearchForProduct.setColumns(10);

		/** When the user presses the log out button
		 * the singleton class fields are reset and the login screen is displayed
		 */
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CurrentSession.getInstance().logout();
				new LoginForm();
				dispose();
			}
		});
		btnLogOut.setBounds(725, 12, 206, 29);
		panel.add(btnLogOut);
		btnLogOut.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));

		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(40, 50, 64));
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(332, 105, 21, 545);

		this.contentPane.add(separator);

		this.cbRefineBy = new JComboBox();
		this.cbRefineBy.setModel(new DefaultComboBoxModel(
				new String[] { "Relevance", "Price: Low to High", "Price: High to Low", "Avg. Customer Review" }));
		this.cbRefineBy.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.cbRefineBy.setBounds(23, 621, 183, 29);
		this.contentPane.add(this.cbRefineBy);

		/**
		 * If the combobox changes then the list is refreshed with the new results
		 */
		JButton btnRefine = new JButton("Refine");
		btnRefine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				searchProducts();
			}
		});

		btnRefine.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnRefine.setBounds(215, 621, 94, 29);
		this.contentPane.add(btnRefine);

		JLabel lblProductName = new JLabel("Product Details");
		lblProductName.setForeground(Color.BLACK);
		lblProductName.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblProductName.setBackground(Color.WHITE);
		lblProductName.setBounds(351, 105, 385, 48);
		this.contentPane.add(lblProductName);

		JLabel lblBy = new JLabel("by");
		lblBy.setForeground(Color.BLACK);
		lblBy.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblBy.setBackground(Color.WHITE);
		lblBy.setBounds(351, 148, 13, 22);
		this.contentPane.add(lblBy);

		JLabel lblSellersName = new JLabel("Seller's Name");
		lblSellersName.setForeground(Color.BLACK);
		lblSellersName.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblSellersName.setBackground(new Color(255, 204, 0));
		lblSellersName.setBounds(371, 148, 125, 22);
		this.contentPane.add(lblSellersName);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBackground(new Color(40, 50, 64));
		separator_1.setBounds(351, 172, 360, 10);
		this.contentPane.add(separator_1);

		JLabel lblPrice = new JLabel("Price  :");
		lblPrice.setForeground(Color.BLACK);
		lblPrice.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblPrice.setBackground(Color.WHITE);
		lblPrice.setBounds(351, 181, 55, 22);
		this.contentPane.add(lblPrice);

		JLabel lblStock = new JLabel("Stock  :");
		lblStock.setForeground(Color.BLACK);
		lblStock.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblStock.setBackground(Color.WHITE);
		lblStock.setBounds(351, 247, 55, 22);
		this.contentPane.add(lblStock);

		JLabel lblRating = new JLabel("Rating :");
		lblRating.setForeground(Color.BLACK);
		lblRating.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblRating.setBackground(Color.WHITE);
		lblRating.setBounds(351, 214, 55, 22);
		this.contentPane.add(lblRating);

		JLabel lblDetails = new JLabel("Details");
		lblDetails.setForeground(Color.BLACK);
		lblDetails.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblDetails.setBackground(Color.WHITE);
		lblDetails.setBounds(351, 277, 104, 22);
		this.contentPane.add(lblDetails);

		JLabel lblVariablePrice = new JLabel("");
		lblVariablePrice.setForeground(Color.BLACK);
		lblVariablePrice.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblVariablePrice.setBackground(Color.WHITE);
		lblVariablePrice.setBounds(400, 181, 116, 22);
		this.contentPane.add(lblVariablePrice);

		JLabel lblVariablestock = new JLabel("");
		lblVariablestock.setForeground(Color.BLACK);
		lblVariablestock.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblVariablestock.setBackground(Color.WHITE);
		lblVariablestock.setBounds(400, 247, 116, 22);
		this.contentPane.add(lblVariablestock);

		this.lblVariableRating = new JLabel("");
		this.lblVariableRating.setForeground(Color.BLACK);
		this.lblVariableRating.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.lblVariableRating.setBackground(Color.WHITE);
		this.lblVariableRating.setBounds(400, 214, 116, 22);
		this.contentPane.add(this.lblVariableRating);

		/**
		 * Adds a product to the basket along with a quantity
		 * validation is checked before performing the process
		 */
		JButton btnAddToBasket = new JButton("Add to basket");
		btnAddToBasket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String[] parts = lblProductName.getText().split(" //| ");
				String getId = parts[0];
				if (txtSelectQuantity.getText().matches("[1-9][0-9]*")) {
					if (Integer.parseInt(txtSelectQuantity.getText()) <= Integer.parseInt(lblVariablestock.getText())) {
						customer.addToBasket(Integer.parseInt(getId), Integer.parseInt(txtSelectQuantity.getText()));
						JOptionPane.showMessageDialog(null, "Item added to basket");
					} else {
						JOptionPane.showMessageDialog(null, "Not enough stock available");
					}

				} else {
					JOptionPane.showMessageDialog(null, "Enter valid input!");
				}
			}
		});
		btnAddToBasket.setEnabled(false);
		btnAddToBasket.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnAddToBasket.setBounds(746, 343, 187, 29);
		this.contentPane.add(btnAddToBasket);

		/**
		 * Adds a product to the wishlist or removes a product from the wishlist
		 */
		JButton btnAddToWishlist = new JButton("Add to wishlist");
		btnAddToWishlist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String[] parts = lblProductName.getText().split(" //| ");
				String getId = parts[0];
				if (btnAddToWishlist.getText().equals("Remove from Wishlist")) {
					customer.removeFromWishlist(Integer.parseInt(getId));
					JOptionPane.showMessageDialog(null, "Item removed from Wishlist");
					btnAddToWishlist.setText("Add to Wishlist");
					;
				} else {
					customer.addToWishlist(Integer.parseInt(getId));
					JOptionPane.showMessageDialog(null, "Item added to Wishlist");
					btnAddToWishlist.setText("Remove from Wishlist");
					;
				}

			}
		});

		btnAddToWishlist.setEnabled(false);
		btnAddToWishlist.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnAddToWishlist.setBounds(746, 383, 187, 29);
		this.contentPane.add(btnAddToWishlist);

		this.listProducts = new JList();
		this.listProducts.setBackground(UIManager.getColor("Button.background"));
		this.listProducts.setLayoutOrientation(JList.VERTICAL_WRAP);
		this.listProducts.setSelectedIndex(0);
		this.listProducts.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.listProducts.setBounds(23, 105, 286, 505);
		this.contentPane.add(this.listProducts);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(null);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(351, 310, 369, 124);
		scrollPane.setBorder(null);
		this.contentPane.add(scrollPane);

		JTextArea lblVariabledetails = new JTextArea();
		scrollPane.setViewportView(lblVariabledetails);
		lblVariabledetails.setForeground(Color.BLACK);
		lblVariabledetails.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblVariabledetails.setLineWrap(true);
		lblVariabledetails.setEditable(false);
		lblVariabledetails.setBackground(UIManager.getColor("Button.background"));

		JLabel lblPage = new JLabel("Menu");
		lblPage.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPage.setForeground(Color.BLACK);
		lblPage.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblPage.setBackground(Color.WHITE);
		lblPage.setBounds(746, 638, 187, 34);
		this.contentPane.add(lblPage);

		/**
		 *  When the field is not empty, the user can then press the add to basket
		 *  this prevents the user from pressing the button if the user has not pressed an item in the list or has nor selected a quantity
		 */
		this.txtSelectQuantity = new JTextField();
		this.txtSelectQuantity.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void changedUpdate(DocumentEvent arg0) {
				check();
			}

			@Override
			public void insertUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				check();
			}

			@Override
			public void removeUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				check();
			}

			public void check() {

				if (listProducts.isSelectionEmpty() || txtSelectQuantity.getText().isEmpty()) {
					btnAddToBasket.setEnabled(false);
				} else {
					btnAddToBasket.setEnabled(true);
				}

			}
		});
		this.txtSelectQuantity.setToolTipText("");
		this.txtSelectQuantity.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.txtSelectQuantity.setColumns(10);
		this.txtSelectQuantity.setBounds(884, 308, 49, 29);
		this.contentPane.add(this.txtSelectQuantity);

		JLabel lblSelectQuantity = new JLabel("Select Quantity :");
		lblSelectQuantity.setHorizontalAlignment(SwingConstants.LEFT);
		lblSelectQuantity.setForeground(Color.BLACK);
		lblSelectQuantity.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblSelectQuantity.setBackground(Color.WHITE);
		lblSelectQuantity.setBounds(746, 303, 141, 34);
		this.contentPane.add(lblSelectQuantity);

		JLabel lblReviews = new JLabel("Reviews:");
		lblReviews.setForeground(Color.BLACK);
		lblReviews.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblReviews.setBackground(Color.WHITE);
		lblReviews.setBounds(351, 441, 104, 22);
		this.contentPane.add(lblReviews);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setViewportBorder(null);
		scrollPane_1.setBounds(351, 474, 578, 150);
		scrollPane_1.setBorder(null);
		this.contentPane.add(scrollPane_1);

		this.lblListOfReviews = new JTextArea();
		scrollPane_1.setViewportView(this.lblListOfReviews);
		this.lblListOfReviews.setLineWrap(true);
		this.lblListOfReviews.setForeground(Color.BLACK);
		this.lblListOfReviews.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.lblListOfReviews.setEditable(false);
		this.lblListOfReviews.setBackground(UIManager.getColor("Button.background"));

		/**
		 * Adds a review for the selected product or removes a review
		 */
		JButton btnAddAReview = new JButton("Add a Review");
		btnAddAReview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String[] parts = lblProductName.getText().split(" //| ");
				String getId = parts[0];

				if (btnAddAReview.getText().equals("Add a Review")) {
					AddReviewForm.getObj(Integer.parseInt(getId)).setVisible(true);
					btnAddAReview.setText("Remove Your Review");

					AddReviewForm.getObj(Integer.parseInt(getId)).addWindowListener(new java.awt.event.WindowAdapter() {
						/** Only after the new review has been added the following occurs */
						@Override
						public void windowClosed(java.awt.event.WindowEvent windowEvent) {
							if (customer.existInReview(Integer.parseInt(parts[0]))) {
								btnAddAReview.setText("Remove Your Review");
							} else {
								btnAddAReview.setText("Add a Review");
							}

							refreshReviews();
						}

					});

				} else {
					customer.deleteReview(Integer.parseInt(getId));
					btnAddAReview.setText("Add a Review");
				}
				refreshReviews();

			}
		});

		btnAddAReview.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnAddAReview.setEnabled(false);
		btnAddAReview.setBounds(746, 423, 187, 29);
		this.contentPane.add(btnAddAReview);

		JSeparator separator_2 = new JSeparator();
		separator_2.setBackground(new Color(40, 50, 64));
		separator_2.setBounds(351, 463, 582, 15);
		this.contentPane.add(separator_2);

		JSeparator separator_3 = new JSeparator();
		separator_3.setBackground(new Color(40, 50, 64));
		separator_3.setBounds(351, 302, 582, 2);
		this.contentPane.add(separator_3);

		/**
		 * Displays the wishlist form 
		 */
		JButton btnMyWishlist = new JButton("My Wishlist");
		btnMyWishlist.setBounds(730, 221, 203, 34);
		this.contentPane.add(btnMyWishlist);
		btnMyWishlist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WishlistForm.getObj().setVisible(true);
			}
		});
		btnMyWishlist.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));

		/**
		 * Displays the basket form
		 */
		JButton btnMyBasket = new JButton("My Basket");
		btnMyBasket.setBounds(730, 181, 203, 34);
		this.contentPane.add(btnMyBasket);
		btnMyBasket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BasketForm.getObj().setVisible(true);
			}
		});
		btnMyBasket.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));

		/**
		 * Displays the account form
		 */
		JButton btnYourAccount = new JButton("Your Account");
		btnYourAccount.setBounds(730, 141, 203, 34);
		this.contentPane.add(btnYourAccount);
		btnYourAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerProfile.getObj().setVisible(true);
			}
		});
		btnYourAccount.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));

		/**
		 * Displays the MyProduct form
		 */
		JButton btnMyProducts = new JButton("My Products");
		btnMyProducts.setBounds(730, 100, 203, 34);
		this.contentPane.add(btnMyProducts);
		btnMyProducts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyProductsForm.getObj().setVisible(true);
			}
		});
		btnMyProducts.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		
		/**
		 * Displays the transaction form
		 */
		JButton btnTransaction = new JButton("Transactions");
		btnTransaction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TransactionForm.getObj().setVisible(true);
				
			}
		});
		btnTransaction.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnTransaction.setBounds(730, 263, 203, 34);
		this.contentPane.add(btnTransaction);

		/**
		 * When a product has been selected, its details are loaded onto JLabels
		 */
		this.listProducts.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				// TODO Auto-generated method stub
				connect = DBConnection.connect();

				if (listProducts.getSelectedIndex() != -1) {
					String[] parts = listProducts.getSelectedValue().split(" \\| ");
					String selectedValue = parts[1];
					txtSelectQuantity.setText(null);
					btnAddAReview.setEnabled(true);
					btnAddToWishlist.setEnabled(true);
					PreparedStatement pst = null;
					ResultSet rs = null;

					try {
						final String query = "SELECT * FROM Product WHERE Product_ID=?";
						pst = connect.prepareStatement(query);
						pst.setInt(1, productID.get(selectedValue));
						rs = pst.executeQuery();
						String name = rs.getString("Name");
						name = name.substring(0, 1).toUpperCase() + name.substring(1);
						Product product = new Product(rs.getInt("Product_ID"));
						lblSellersName.setText(product.getSeller().getUsername());
						lblProductName.setText(id.format(product.getProductID()) + " | " + name);
						lblVariabledetails.setText(product.getDescription());
						lblVariablestock.setText(rs.getString("Current_Stock"));
						lblVariablePrice.setText("�" + rs.getString("Cost"));
						lblVariableRating.setText("N/A");
					} catch (Exception a) {
						a.printStackTrace();
					} finally {
						if (rs != null) {
							try {
								rs.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						if (pst != null) {
							try {
								pst.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}

					refreshReviews();

					if (customer.existInWishlist(Integer.parseInt(parts[0]))) {
						btnAddToWishlist.setText("Remove from Wishlist");
					} else {
						btnAddToWishlist.setText("Add to Wishlist");
					}

					if (customer.existInReview(Integer.parseInt(parts[0]))) {
						btnAddAReview.setText("Remove Your Review");
					} else {
						btnAddAReview.setText("Add a Review");
					}

					if (lblListOfReviews.getText().isEmpty()) {
						lblListOfReviews.setText("No Reviews for this product");
						lblVariableRating.setText("N/A");
					}

				}

			}
		});

		if (this.listProducts.getSelectedIndex() == -1) {
			btnAddToWishlist.setEnabled(false);
			btnAddToBasket.setEnabled(false);
		}

		loadProducts();
	}

	/**
	 * Loads the list of review for the selected product
	 */
	public void refreshReviews() {
		String[] parts = this.listProducts.getSelectedValue().split(" \\| ");
		String name = parts[1];
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		StringBuffer list = null;

		try {
			list = new StringBuffer();
			final String query = "SELECT Username, Rating, Review FROM Customer_Product_Reviews INNER JOIN User ON Customer_Product_Reviews.User_ID=User.User_ID WHERE Product_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, productID.get(name));
			rs = pst.executeQuery();
			int average = 0;
			int counter = 0;
			while (rs.next()) {
				list.append(rs.getString("Review") + "\n");
				list.append("By " + rs.getString("Username"));
				list.append("  [Rating: " + rs.getString("Rating") + "]\n\n");
				average += rs.getInt("Rating");
				counter++;
			}
			this.lblListOfReviews.setText(list.toString());
			if (average == 0) {
				this.lblVariableRating.setText("N/A");
			} else {

				this.lblVariableRating.setText(Integer.toString(average / counter) + "/5");
			}
		} catch (Exception a) {
			a.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Allows the user to query for a particular product, user can filter through using
	 * two combo boxes.
	 */
	public void searchProducts() {
		this.connect = DBConnection.connect();
		StringBuffer query = new StringBuffer(
				"SELECT * FROM Product WHERE Verified=1 AND LOWER(Name) LIKE '%'||?||'%' AND Category=?");

		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			this.productID = new HashMap<>();
			if (this.cbSearchBy.getSelectedItem().toString().equals("ALL")) {
				query = new StringBuffer("SELECT * FROM Product WHERE Verified=1 AND LOWER(Name) LIKE '%'||?||'%'");
			}

			if (this.cbRefineBy.getSelectedIndex() == 1) {
				query.append(" ORDER BY Cost ASC");
			}

			if (this.cbRefineBy.getSelectedIndex() == 2) {
				query.append(" ORDER BY Cost DESC");
			}

			if (this.cbRefineBy.getSelectedIndex() == 3) {

			}

			pst = this.connect.prepareStatement(query.toString());
			pst.setString(1, this.txtSearchForProduct.getText().toLowerCase());
			if (!this.cbSearchBy.getSelectedItem().toString().equals("ALL")) {
				pst.setString(2, this.cbSearchBy.getSelectedItem().toString());
			}

			rs = pst.executeQuery();
			DefaultListModel<String> list = new DefaultListModel<String>();
			int counter = 0;
			while (rs.next()) {
				String name = rs.getString("Name");
				name = name.substring(0, 1).toUpperCase() + name.substring(1);
				list.addElement(
						this.id.format(rs.getInt("Product_ID")) + " | " + name + " | �" + this.cost.format(rs.getDouble("Cost")));
				this.productID.put(name, rs.getInt("Product_ID"));
				counter++;
			}

			if (counter > 0) {
				this.listProducts.setModel(list);
			} else {
				list.removeAllElements();
				this.listProducts.setModel(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * Initially loads all the products into the JList
	 */
	public void loadProducts() {
		this.connect = DBConnection.connect();
		String query = "SELECT * FROM Product WHERE Verified=1 AND Category=?";
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			this.productID = new HashMap<>();
			if (this.cbSearchBy.getSelectedItem().toString().equals("ALL")) {
				query = "SELECT * FROM Product WHERE Verified=1";
			}
			pst = this.connect.prepareStatement(query);
			if (!this.cbSearchBy.getSelectedItem().toString().equals("ALL")) {
				pst.setString(1, this.cbSearchBy.getSelectedItem().toString());
			}
			rs = pst.executeQuery();
			DefaultListModel<String> list = new DefaultListModel<String>();
			int counter = 0;
			while (rs.next()) {
				String name = rs.getString("Name");
				name = name.substring(0, 1).toUpperCase() + name.substring(1);
				list.addElement(
						this.id.format(rs.getInt("Product_ID")) + " | " + name + " | �" + this.cost.format(rs.getDouble("Cost")));
				this.productID.put(name, rs.getInt("Product_ID"));
				counter++;
			}
			if (counter > 0) {
				this.listProducts.setModel(list);
			} else {
				list.removeAllElements();
				this.listProducts.setModel(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}
}
