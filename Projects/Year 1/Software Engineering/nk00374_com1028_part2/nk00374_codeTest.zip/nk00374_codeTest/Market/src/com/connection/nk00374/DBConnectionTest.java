/**
 * DBConnectionTest.java
 */
package com.connection.nk00374;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Test;
/**
 * 
 * @author Nithesh Koneswaran
 *
 */
public class DBConnectionTest {

	/** Tests the connection of the DB Class */
	@Test
	public void testDBConnection() {
		try {
			Connection connect = DBConnection.connect();
			connect.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
