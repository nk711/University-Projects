/**
 * ProductTest.java
 */
package com.market.test.nk00374;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.Customer;
import com.market.nk00374.GroupType;
import com.market.nk00374.Product;
import com.market.nk00374.ProductCategory;
import com.market.nk00374.ProductType;
import com.market.nk00374.Review;
/**
 *  COMPREHENSIVE UNIT TESTING!!!
 *  
 *  
 * @author Nithesh Koneswaran
 *
 */
public class ProductTest {

	/**
	 * sets up the database before the actual object creation test
	 * Creating Product
	 */
	@Before
	public void setUp() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;
	
		try {
			query = "INSERT INTO User VALUES (999, ?, ?, ?, ?, ?, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setString(1, "Nithesh");
			pst.setString(2, "Koneswaran");
			pst.setString(3, "nk00374");
			pst.setString(4, "test12345");
			pst.setString(5, "07/11/1998");
			pst.setString(6, "nk00374@surrey.ac.uk");
			pst.setString(7, "02084758387");
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

		try {
			query = "INSERT INTO Customer VALUES (999, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setDouble(1, 1000.0);
			pst.setString(2, GroupType.UNBANNED.toString());
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

		
		
		try {
			query = "INSERT INTO Product VALUES (999, ?, ?, ?, ?, ?, ?, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setString(1, "Product");
			pst.setString(2, "Very good product");
			pst.setInt(3, 23);
			pst.setInt(4, 23);
			pst.setDouble(5, 12.99);
			pst.setInt(6, 0);
			pst.setInt(7, 0);
			pst.setString(8, ProductCategory.CLOTHING.toString());
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "INSERT INTO Customer_Registered_Product VALUES (999, 999)";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
	}

	/**
	 * Tears down the data we just added
	 */
	@After
	public void tearDown() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;
		
		try {
			query = "DELETE FROM Customer_Registered_Product WHERE Product_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

		try {
			query = "DELETE FROM Product WHERE Product_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM User WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Customer WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		
		
	}

	/**
	 * Creates a product object Checks a sample of methods to see if it returns
	 * This also tests the initialise method in the product clas
	 * correct values
	 */
	@Test
	public void testConstructor1() {
		Product product = new Product(999);
		assertEquals("Product", product.getTitle());
		assertEquals("Very good product", product.getDescription());
		assertEquals(23, product.getInitialStock());
		assertEquals(ProductType.NONVERIFIED, product.getType());
	}


	/**
	 * Creates a product object Checks a sample of methods to see if it returns
	 * correct values
	 */
	@Test
	public void testConstructor2() {
		Product product = new Product(23,"Product",23,23.34);
		assertEquals("Product", product.getTitle());
		assertEquals(23, product.getStock());

	}
	
	/**
	 * Creates a Product object and if an error is thrown in case of invalid id
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidConstructor1() {
		Product product = new Product(-23,"Product",23,23.34);
		assertEquals("Product", product.getTitle());
		assertEquals(23, product.getStock());
		assertEquals("", product.reviewToString());
	}
	
	/**
	 * Creates a Product object and if an error is thrown in case of invalid id
	 */
	@Test(expected = NullPointerException.class)
	public void testInvalidConstructor2() {
		Product product = new Product(23,null,23,23.34);
		assertEquals("Product", product.getTitle());
		assertEquals(23, product.getStock());
		assertEquals("", product.reviewToString());
	}
	
	/**
	 * Creates a Product object and if an error is thrown in case of invalid id
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidConstructor3() {
		Product product = new Product(-23);
		assertEquals("Product", product.getTitle());
		assertEquals("Very good product", product.getDescription());
		assertEquals(23, product.getInitialStock());
		assertEquals(ProductType.VERIFIED, product.getType());
		assertEquals(null, product.reviewToString());
	}
	
	/**
	 * Tests the accessors of the Product class
	 */
	@Test
	public void testGetters() {
		Customer customer = new Customer(999);
		Product product = new Product(999);
		assertEquals("Product", product.getTitle());
		assertEquals("Very good product", product.getDescription());
		assertEquals(23, product.getInitialStock());
		assertEquals(ProductType.NONVERIFIED, product.getType());
		assertEquals(0,product.getAgeRestriction(),0);
		assertEquals(ProductCategory.CLOTHING, product.getCategory());
		assertEquals(12.99, product.getPrice(), 0);
		assertEquals(999, product.getProductID(),0);
		assertEquals(0,product.getRating(),0);
		assertEquals(new ArrayList<Review>(), product.getReviews());
		assertEquals(customer.getClass(), product.getSeller().getClass());
		assertEquals(0, product.getSold(), 0);
		assertEquals(23, product.getStock(), 0);
	}
		
	/**
	 * Adds a review to a product and then calculates the avg review of the product
	 */
	@Test
	public void testRating() {
		Customer customer = new Customer(999);
		Product product = new Product(999);
		Review review = new Review(999,999, 5,"Very good product");
		customer.addToReviewList(review);
		product.initialise();
		assertEquals(5,product.getRating());
		customer.deleteReview(product.getProductID());
	}
	
	/**
	 * Adds a review to a product and then calculates the avg review of the product
	 * Note: Product initialise will update the product'attributes after an SQL operation such are adding/removing a remove
	 */
	@Test
	public void testReview() {
		Customer customer = new Customer(999);
		Product product = new Product(999);
		Review review = new Review(999,999, 5,"Very good product");
		customer.addToReviewList(review);
		product.initialise();
		assertEquals("Very good product",product.getReviews().get(0).getReview());
		assertEquals("Very good product\n" + 
					"By nk00374  [Rating: 5]\n\n",product.reviewToString());
		customer.deleteReview(product.getProductID());
	}
	
	/**
	 *  Tests if you can set the stock for a product that is less than 0
	 *  An IllegalArgumentException should appear
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidSetStock() {
		Product product = new Product(999);
		product.setStock(-23);
	}
	
	/**
	 * Sets the products stock which effectively updates the changes to the database
	 */
	@Test
	public void testSetStock() {
		Product product = new Product(999);
		product.setStock(2000);
		assertEquals(2000, product.getStock());
	}
	
	/**
	 *  Tests if you can set the type for a product as null
	 *  An NullPointerException should appear
	 */
	@Test(expected = NullPointerException.class)
	public void testInvalidSetType() {
		Product product = new Product(999);
		product.setType(null);
		
	}
	
	/**
	 * Sets the products type which is updated in the database
	 */
	@Test
	public void testSetType() {
		Product product = new Product(999);
		product.setType(ProductType.VERIFIED);
		assertEquals(ProductType.VERIFIED, product.getType());
	}
	
	/**
	 * Simulates a user buying the product which should subtract the stock of the product.
	 * The getter method in the product should then calculate how many had been sold.
	 */
	@Test
	public void testGetHowManySold() {
		Customer customer = new Customer(999);
		Product product = new Product(999);
		product.setStock(20);
		customer.setBalance(10000);
		customer.addToBasket(999, 2);
		customer.buyBasket();
		assertEquals(product.getInitialStock()-product.getStock(), product.getSold());
	}
	
}
