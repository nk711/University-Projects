/**
 * TransactionTest.java
 */
package com.market.test.nk00374;
import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.junit.Test;
import com.market.nk00374.Transaction;
/**
 * 
 * @author Nithesh Koneswaran
 *
 */
public class TransactionTest {
	/**
	 * Tests the constructor in the transaction class
	 */
	@Test
	public void testConstructor() {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		String date = format.format(new Date());
		Transaction transaction = new Transaction(23, date.toString(), 23);
		assertEquals(date, transaction.getDate());
		assertEquals(23, transaction.getQuantity());
		assertEquals(23, transaction.getProductID());
	}
	
	/**
	 * Creating a transaction object with invalid parameters
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidConstructor1() {
		Transaction transaction = new Transaction(-23, "", 23);
		assertEquals(23, transaction.getQuantity());
		assertEquals(23, transaction.getProductID());
	}
	
	/**
	 * Creating a transaction object with invalid parameters
	 */
	@Test(expected = NullPointerException.class)
	public void testInvalidConstructor2() {
		Transaction transaction = new Transaction(23, null, 23);
		assertEquals(23, transaction.getQuantity());
		assertEquals(23, transaction.getProductID());
	}

}
