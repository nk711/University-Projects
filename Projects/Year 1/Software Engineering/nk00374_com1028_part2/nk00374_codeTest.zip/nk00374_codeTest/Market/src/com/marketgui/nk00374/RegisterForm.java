/**
 * RegisterForm.java
 */
package com.marketgui.nk00374;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.Customer;

import java.awt.TextField;
import java.awt.event.ActionListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.awt.event.ActionEvent;
import java.util.Calendar;
import java.util.Date;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.*;
/**
 * @author Nithesh Koneswaran
 *
 */
public class RegisterForm extends JFrame {
	private JPanel contentPane;
	/** Hold the user's firstname */
	private JTextField txtFirstName;
	/** Hold the user's surname */
	private JTextField txtSurname;
	/** Hold the user's username */
	private JTextField txtUsername;
	/** Hold the user's password */
	private JTextField txtPassword;
	/** Hold the user's email */
	private JTextField txtEmail;
	/** Hold the user's telephone */
	private JTextField txtTelephone;
	/** Hold the user's date of birth */
	private JTextField txtDateOfBirth;
	/** Provides a connection to the database*/
	private Connection connect;
	/** An error message in case of invalid validation*/
	private StringBuffer message = new StringBuffer("Failed to register: \n");
	/** The current customer logged in */
	private Customer customer;
	/** Regex for only letters, telephone and date */
	private final static String ALPHABET = "[a-zA-Z]+";
	private final static String NUMBERS = "([0-9]{11})";
	private final static String DATE = "([0-9]{2})/([0-1][0-9])/([0-9]{4})";


	/**
	 * Create the frame.
	 */
	public RegisterForm() {
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 367, 336);
		this.contentPane = new JPanel();
		this.contentPane.setBackground(UIManager.getColor("Button.background"));
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		JLabel lblForename = new JLabel("First Name     ");
		lblForename.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblForename.setBounds(10, 130, 94, 22);
		this.contentPane.add(lblForename);

		JLabel lblSurname = new JLabel("Surname       ");
		lblSurname.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblSurname.setBounds(10, 163, 94, 22);
		this.contentPane.add(lblSurname);

		JLabel lblDateOfBirth = new JLabel("Date of Birth ");
		lblDateOfBirth.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblDateOfBirth.setBounds(10, 262, 114, 22);
		this.contentPane.add(lblDateOfBirth);

		JLabel lblEmail = new JLabel("Email        ");
		lblEmail.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblEmail.setBounds(10, 229, 114, 22);
		this.contentPane.add(lblEmail);

		JLabel lblTelephone = new JLabel("Telephone ");
		lblTelephone.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblTelephone.setBounds(10, 196, 114, 22);
		this.contentPane.add(lblTelephone);

		JLabel lblUsername = new JLabel("Username ");
		lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblUsername.setBounds(10, 64, 83, 22);
		this.contentPane.add(lblUsername);

		JLabel lblPassword = new JLabel("Password  ");
		lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblPassword.setBounds(10, 97, 83, 22);
		this.contentPane.add(lblPassword);

		/** 
		 * When the user press the submit button a new account will be created and added to the database
		 * Validation is checked prior to creating a new account
		 */
		Button btnSignUp = new Button("Submit");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!validation()) {
					JOptionPane.showMessageDialog(null, message.toString());
				}
				if (accountExists()) {
					JOptionPane.showMessageDialog(null, "Username already Exists");
				}
				if (validation() && !accountExists()) {
					addUser();
				}
			}
		});
		
		btnSignUp.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnSignUp.setEnabled(true);
		btnSignUp.setBounds(231, 262, 101, 26);
		this.contentPane.add(btnSignUp);

		this.txtDateOfBirth = new JTextField();
		this.txtDateOfBirth.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtDateOfBirth.setColumns(10);
		this.txtDateOfBirth.setBounds(101, 263, 121, 25);
		this.contentPane.add(this.txtDateOfBirth);

		this.txtUsername = new JTextField();
		this.txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtUsername.setColumns(10);
		this.txtUsername.setBounds(101, 65, 231, 25);
		this.contentPane.add(this.txtUsername);

		this.txtPassword = new JTextField();
		this.txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtPassword.setColumns(10);
		this.txtPassword.setBounds(101, 98, 231, 25);
		this.contentPane.add(this.txtPassword);

		this.txtFirstName = new JTextField();
		this.txtFirstName.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtFirstName.setColumns(10);
		this.txtFirstName.setBounds(101, 131, 231, 25);
		this.contentPane.add(this.txtFirstName);

		this.txtSurname = new JTextField();
		this.txtSurname.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtSurname.setColumns(10);
		this.txtSurname.setBounds(101, 164, 231, 25);
		this.contentPane.add(this.txtSurname);

		this.txtTelephone = new JTextField();
		this.txtTelephone.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtTelephone.setColumns(10);
		this.txtTelephone.setBounds(101, 197, 231, 25);
		this.contentPane.add(this.txtTelephone);

		this.txtEmail = new JTextField();
		this.txtEmail.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtEmail.setColumns(10);
		this.txtEmail.setBounds(101, 230, 231, 25);
		this.contentPane.add(this.txtEmail);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(40, 50, 63));
		panel.setBounds(0, 0, 351, 53);
		this.contentPane.add(panel);
		
		JLabel lblRegister = new JLabel("Register");
		lblRegister.setForeground(new Color(222, 209, 63));
		lblRegister.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblRegister.setBackground(Color.WHITE);
		lblRegister.setBounds(10, 11, 119, 34);
		panel.add(lblRegister);
		
		/**
		 *  This will create a new admin instead of a customer
		 *  this is only implemented for test purposes,
		 *  
		 */
		Button button = new Button("Create Admin");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				connect = DBConnection.connect();
				boolean errors = false;
				String firstName = txtFirstName.getText().toLowerCase();
				String surname = txtSurname.getText().toLowerCase();
				firstName = firstName.substring(0, 1).toUpperCase() + firstName.substring(1);
				surname = surname.substring(0, 1).toUpperCase() + surname.substring(1);
				String query = null;
				PreparedStatement pst = null; 
				ResultSet rs = null;

				try { 
					query = "INSERT INTO user VALUES (null, ?, ?, ?, ?, ?, ?, ?)";
					pst = connect.prepareStatement(query);
					pst.setString(1, firstName);
					pst.setString(2, surname);
					pst.setString(3, txtUsername.getText());
					pst.setString(4, hash(txtPassword.getText()));
					pst.setString(5, txtDateOfBirth.getText());
					pst.setString(6, txtEmail.getText());
					pst.setString(7, txtTelephone.getText());
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Account Created!");
				} catch (Exception error) {
					errors = true;
					error.printStackTrace();
				} finally {
					if (rs != null) {
						try {
							rs.close();
						} catch (Exception error) {
							errors = true;
							error.printStackTrace();
						}
					}
					if (pst != null) {
						try {
							pst.close();
						} catch (Exception error) {
							errors = true;
							error.printStackTrace();
						}
					}
				}
				
				try {
					query = "INSERT INTO Administrator VALUES (null, (SELECT last_insert_rowid()))";
					pst = connect.prepareStatement(query);
					pst.executeUpdate();
				} catch (Exception error) {
					errors = true;
					error.printStackTrace();
				} finally {
					if (rs != null) {
						try {
							rs.close();
						} catch (Exception error) {
							errors = true;
							error.printStackTrace();
						}
					}
					if (pst != null) {
						try {
							pst.close();
						} catch (Exception error) {
							errors = true;
							error.printStackTrace();
						}
					}
				}

				if (!errors) {
					dispose();
					new LoginForm();
				} else {
					JOptionPane.showMessageDialog(null, "Unsuccessful, Try again");
				}

				
			}
		});
		button.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		button.setEnabled(true);
		button.setBounds(240, 11, 101, 34);
		panel.add(button);
		
		
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			 public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		        dispose();
		    	new LoginForm();
		    }
		});
		
	}

	/**
	 * Adds the user to the database
	 */
	public void addUser() {
		this.connect = DBConnection.connect();
		boolean errors = false;
		String firstName = this.txtFirstName.getText().toLowerCase();
		String surname = this.txtSurname.getText().toLowerCase();
		firstName = firstName.substring(0, 1).toUpperCase() + firstName.substring(1);
		surname = surname.substring(0, 1).toUpperCase() + surname.substring(1);
		String query = null;
		PreparedStatement pst = null; 
		ResultSet rs = null;

		try {
			query = "INSERT INTO user VALUES (null, ?, ?, ?, ?, ?, ?, ?)";
			pst = this.connect.prepareStatement(query);
			pst.setString(1, firstName);
			pst.setString(2, surname);
			pst.setString(3, this.txtUsername.getText());
			pst.setString(4, hash(this.txtPassword.getText()));
			pst.setString(5, this.txtDateOfBirth.getText());
			pst.setString(6, this.txtEmail.getText());
			pst.setString(7, this.txtTelephone.getText());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "Account Created!");
		} catch (Exception e) {
			errors = true;
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					errors = true;
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					errors = true;
					e.printStackTrace();
				}
			}
		}

		try {
			query = "INSERT INTO Customer VALUES ((SELECT last_insert_rowid()), 0, ?)";
			pst = this.connect.prepareStatement(query);
			pst.setString(1, "UNBANNED");
			pst.executeUpdate();
		} catch (Exception e) {
			errors = true;
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					errors = true;
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					errors = true;
					e.printStackTrace();
				}
			}
		}

		if (!errors) {
			dispose();
			new LoginForm();
		} else {
			JOptionPane.showMessageDialog(null, "Unsuccessful, Try again");
		}
	}

	/**
	 * @returns True if the account exists in the database
	 * 			false if not
	 */
	public boolean accountExists() {
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		boolean exists = false;
		try {
			final String query = "SELECT * FROM user WHERE username=?";
			pst = this.connect.prepareStatement(query);
			pst.setString(1, this.txtUsername.getText());
			rs = pst.executeQuery();
			int counter = 0;
			while (rs.next()) {
				counter++;
			}
			if (counter != 0) {
				exists = true;
			}
		} catch (Exception e) {
			exists = true;
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		return exists;
	}

	/**
	 * @returns true if the validation is valid
	 * 			false if the validation is invalid 
	 */
	public boolean validation() {
		boolean validation = true;

		this.message = new StringBuffer("Failed to register: \n");

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, -18);
		Date limit = calendar.getTime();

		if (this.txtFirstName.getText().isEmpty() ||this. txtSurname.getText().isEmpty() || this.txtUsername.getText().isEmpty()
				|| this.txtPassword.getText().isEmpty() || this.txtEmail.getText().isEmpty() || this.txtTelephone.getText().isEmpty()
				|| this.txtDateOfBirth.getText().isEmpty()) {
			validation = false;
			this.message.append("Fields must not be left blank \n");
		} else {

			if (!this.txtFirstName.getText().matches(ALPHABET)) {
				validation = false;
				this.message.append("First name must consist of letters only \n");
			}

			if (!this.txtSurname.getText().matches(ALPHABET)) {
				validation = false;
				this.message.append("Surname must consist of letters only \n");
			}

			if (!this.txtTelephone.getText().matches(NUMBERS)) {
				validation = false;
				this.message.append("Enter valid telephone number \n");
			}

			if (!this.txtDateOfBirth.getText().matches(DATE)) {
				validation = false;
				this.message.append("Date must be in the form of dd/mm/yyyy \n");
			} else {
				Date date;
				try {
					date = format.parse(this.txtDateOfBirth.getText());
					if (limit.before(date)) {
						validation = false;
						this.message.append("You MUST be 18 years or older");
					}
				} catch (ParseException e) {
					validation = false;
				}
			}

		}

		return validation;
	}

	/**
	 *  Security method
	 *  
	 *  
	 * @param password
	 * 				password to be hashed
	 * @returns a hashed password 
	 */ 
	public String hash(String password) {
		String pass;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(password.getBytes());
			pass = new String(md.digest());
			return pass;
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
	}
}
