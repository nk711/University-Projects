/**
 * Product.java
 */
package com.market.nk00374;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.connection.nk00374.DBConnection;

/**
 * 
 * This class defines the behaviour and attributes for a product object
 * 
 * @author Nithesh Koneswaran
 *
 */
public class Product {
	/** This field holds the product's id */
	private int productID = 0;
	/** Holds the seller of the product */
	private Customer seller = null;
	/** Determines any age restriction on the product */
	private int ageRestriction = 0;
	/** Holds the category of the product */
	private ProductCategory category = null;
	/** holds the title of the product */
	private String title = null;
	/** holds the description of the product */
	private String description = null;
	/** holds the stock of the product */
	private int stock = 0;
	/** holds the initial stock of the product when registered */
	private int initialStock = 0;
	/** holds the type of the product */
	private ProductType type = null;
	/** Holds the price of the product */
	private double price = 0.0;
	/** Holds the list of reviews of the product */
	private List<Review> review = null;
	/** Provides a con777777777777777nection to the database */
	private Connection connect;

	/**
	 * Parameterised contructor
	 * 
	 * @param productID
	 *            The product's id
	 * @param title
	 *            The product's title
	 * @param stock
	 *            The product's stock
	 * @param price
	 *            The product's price
	 *
	 */
	public Product(int productID, String title, int stock, double price)
			throws NullPointerException, IllegalArgumentException {
		super();
		if (productID < 0 || price < 0.0 || stock < 0) {
			throw new IllegalArgumentException("Cannot be less than 0!");
		}
		if (title == null) {
			throw new NullPointerException("Cannot be left empty!");
		}

		this.review = new ArrayList<>();
		this.productID = productID;
		this.title = title;
		this.stock = stock;
		this.price = price;
	}

	/**
	 * Parameterised constructor
	 * 
	 * @param productID
	 *            used to initialise the other fields
	 */
	public Product(int productID) throws IllegalArgumentException {
		super();
		if (productID < 0) {
			throw new IllegalArgumentException("Id cannot be less than 0");
		}
		this.productID = productID;
		initialise();

	}

	/**
	 * Uses the product ID to initialise the other fields using SQL to retrieve the
	 * data
	 */
	public void initialise() {
		this.review = new ArrayList<>();
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = null;
		try {
			query = "SELECT * FROM Product WHERE Product_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getProductID());
			rs = pst.executeQuery();

			while (rs.next()) {

				this.title = rs.getString("Name");

				this.ageRestriction = rs.getInt("AgeRestriction");

				this.category = ProductCategory.valueOf(rs.getString("Category"));

				this.description = rs.getString("Details");

				this.stock = rs.getInt("Current_Stock");

				this.initialStock = rs.getInt("Initial_Stock");

				if (rs.getInt("Verified") == 0) {
					this.type = ProductType.NONVERIFIED;
				} else {
					this.type = ProductType.VERIFIED;
				}

				this.price = rs.getDouble("Cost");

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		try {
			query = "SELECT * FROM Customer_Product_Reviews WHERE Product_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.productID);
			rs = pst.executeQuery();
			while (rs.next()) {
				this.review.add(new Review(rs.getInt("product_ID")));
			}
		} catch (Exception a) {
			a.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		try {
			query = "SELECT * FROM Customer_Registered_Product WHERE Product_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getProductID());
			rs = pst.executeQuery();
			while (rs.next()) {
				this.seller = new Customer(rs.getInt("User_ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * @return true if the product has been deleted
	 */
	public boolean deleteProduct() {
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		String query = null;
		boolean success = false;

		try {
			query = "DELETE FROM Product WHERE Product_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.productID);
			pst.executeUpdate();
			success = true;
			/** Closes database connection */
		} catch (Exception e) {
			e.printStackTrace();
			success = false;
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					success = false;
					e.printStackTrace();
				}
			}
		}

		try {
			query = "DELETE FROM Customer_Registered_Product WHERE Product_ID=?";
			pst = connect.prepareStatement(query);
			pst.setInt(1, this.productID);
			pst.executeUpdate();
			success = true;
			/** Closes database connection */
		} catch (Exception e) {
			e.printStackTrace();
			success = false;
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					success = false;
					e.printStackTrace();
				}
			}
		}


		try {
			query = "DELETE FROM Customer_Product_Reviews WHERE Product_ID=?";
			pst = connect.prepareStatement(query);
			pst.setInt(1, this.productID);
			pst.executeUpdate();
		} catch (Exception error) {
			success = false;
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					success = false;
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Customer_Transactions WHERE Product_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.productID);
			pst.executeUpdate();
			success = true;
			/** Closes database connection */
		} catch (Exception e) {
			e.printStackTrace();
			success = false;
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					success = false;
					e.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Customer_Wishlist WHERE Product_ID=?";
			pst = connect.prepareStatement(query);
			pst.setInt(1, this.productID);
			pst.executeUpdate();
			success = true;
			/** Closes database connection */
		} catch (Exception e) {
			e.printStackTrace();
			success = false;
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					success = false;
					e.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Customer_Basket WHERE Product_ID=?";
			pst = connect.prepareStatement(query);
			pst.setInt(1, this.productID);
			pst.executeUpdate();
			success = true;
			/** Closes database connection */
		} catch (Exception e) {
			e.printStackTrace();
			success = false;
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					success = false;
					e.printStackTrace();
				}
			}
		}
		return success;
	}

	/**
	 * @returns the intial stock of the product
	 */
	public int getInitialStock() {
		return this.initialStock;
	}

	/**
	 * @returns the age restriction of a product
	 */
	public int getAgeRestriction() {
		return this.ageRestriction;
	}

	/**
	 * @returns how many of the products have been sold
	 */
	public int getSold() {
		return this.initialStock - this.stock;
	}

	/**
	 * @returns the product's id
	 */
	public int getProductID() {
		return this.productID;
	}

	/**
	 * @returns the seller
	 */
	public Customer getSeller() {
		return this.seller;
	}

	/**
	 * @returns the category
	 */
	public ProductCategory getCategory() {
		return this.category;
	}

	/**
	 * @returns the product's title
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 * @returns the product's description
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * @returns the product's stock
	 */
	public int getStock() {
		return this.stock;
	}

	/**
	 * @param stock
	 *            sets the product's stock
	 */
	public void setStock(int stock) throws IllegalArgumentException {
		if (stock < 0) {
			throw new IllegalArgumentException("Stock cannot be less than 0!");
		}
		String query = null;
		PreparedStatement pst = null;
		this.connect = DBConnection.connect();
		try {
			query = "UPDATE Product SET Current_Stock=? WHERE Product_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, stock);
			pst.setInt(2, this.productID);
			pst.executeUpdate();
			this.stock = stock;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * @returns the type of the product
	 */
	public ProductType getType() {
		return this.type;
	}

	/**
	 * @param type
	 *            Sets the type of the product
	 */
	public void setType(ProductType type) throws NullPointerException {
		if (type == null) {
			throw new NullPointerException("Cannot be left empty!");
		}
		int verified = 0;
		if (type.equals(ProductType.VERIFIED)) {
			verified = 1;
		} else {
			verified = 0;
		}
		String query = null;
		PreparedStatement pst = null;
		this.connect = DBConnection.connect();
		try {
			query = "UPDATE Product SET Verified=? WHERE Product_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, verified);
			pst.setInt(2, this.productID);
			pst.executeUpdate();
			this.type = type;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * @returns the product's price
	 */
	public double getPrice() {
		return this.price;
	}


	/**
	 * @returns the list of reviews
	 */
	public List<Review> getReviews() {
		return this.review;
	}

	/**
	 * @returns the list of reviews as a string
	 */
	public String reviewToString() {
		StringBuffer reviews = new StringBuffer();
		if (!this.review.isEmpty()) {
			for (Review review : this.review) {
				reviews.append(review.getReview() + "\n");
				reviews.append("By " + review.getUsername());
				reviews.append("  [Rating: " + review.getRating() + "]\n\n");
			}
		}
		return reviews.toString();
	}

	/**
	 * @returns the product's rating
	 */
	public int getRating() {
		int avg = 0;
		if (!this.review.isEmpty()) {
			for (Review review : this.review) {
				avg += review.getRating();
			}
			avg = avg / this.review.size();
		}
		return avg;
	}

}
