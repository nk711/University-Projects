/**
 * WishlistForm.java
 */
package com.marketgui.nk00374;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.Product;
import com.market.nk00374.Transaction;

import javax.swing.JTable;
import javax.swing.JTextArea;
/**
 * @author Nithesh Koneswaran
 *
 */
public class WishlistForm extends JFrame {

	private JPanel contentPane;
	/** The currently logged in customer */
	private Customer customer;
	/** Provides a connection to the database */
	private Connection connect;
	/** displays the list of product */
	private JTextArea txtList;
	/** Holds an instance of the Wishlist form */
	private static WishlistForm obj = null;
	/** 
	 * @returns the instance of the Wishlist form if an instance does not exists already
	 */
	public static WishlistForm getObj() {
		if (obj == null) {
			obj = new WishlistForm();
		} else {
			obj.dispose();
			obj = new WishlistForm();
		}
		return obj;
	}

	/**
	 * Create the frame.
	 */
	private WishlistForm() throws NullPointerException {
		this.customer = CurrentSession.getInstance().getCustomer();
		if (this.customer==null) {
			throw new NullPointerException("Customer cannot be null!");
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 340);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 485, 53);
		panel.setLayout(null);
		panel.setForeground(Color.BLACK);
		panel.setBackground(new Color(40, 50, 64));
		this.contentPane.add(panel);

		JLabel lblMyBasket = new JLabel("My Wishlist");
		lblMyBasket.setForeground(new Color(222, 209, 63));
		lblMyBasket.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblMyBasket.setBackground(Color.WHITE);
		lblMyBasket.setBounds(21, 11, 223, 31);
		panel.add(lblMyBasket);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(null);
		scrollPane.setBorder(null);
		scrollPane.setBounds(10, 64, 465, 226);
		this.contentPane.add(scrollPane);

		this.txtList = new JTextArea();
		scrollPane.setViewportView(this.txtList);
		this.txtList.setLineWrap(true);
		this.txtList.setForeground(Color.BLACK);
		this.txtList.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtList.setEditable(false);
		this.txtList.setBackground(SystemColor.menu);

		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				dispose();
			}
		});

		loadWishList();
	}

	/**
	 *  Loads the list of products in the user's wishlist 
	 */
	public void loadWishList() {
		StringBuffer details = new StringBuffer("Wishlist:\n");
		StringBuffer outOfStock = new StringBuffer("Messages: \n");
		for (Product product : this.customer.getWishlist()) {
			details.append("Product name: " + product.getTitle() + "\n");
			details.append("Stock: " + product.getStock() + "\n");
			details.append("Rating: " + product.getRating() + "\n");
			details.append("Cost: �" + product.getPrice() + "\n\n");
			if (product.getStock()==0) {
				outOfStock.append(product.getTitle()+" is out of stock\n");
			} 
		}
		outOfStock.append("\n");
		this.txtList.setText(outOfStock.toString()+details.toString());
	}
}
