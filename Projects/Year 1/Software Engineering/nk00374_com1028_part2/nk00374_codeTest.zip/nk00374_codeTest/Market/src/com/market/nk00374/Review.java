/**
 *  Review.java
 */
package com.market.nk00374;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.connection.nk00374.DBConnection;
/**
 * Defines the behaviour and attribute of a Review object
 * 
 * @author Nithesh Koneswaran
 *
 */
public class Review {
	/**holds the customer's id */
	private int customerID = 0;
	/**holds the customer's username */
	private String username = null;
	/**holds the product's id */
	private int productID = 0;
	/** holds the rating of the product */
	private int rating = 0;
	/** holds the review message */
	private String review = null;
	/** Provides a connection to the database*/
	private Connection connect;


	/**
	 * Parameterised Constructor
	 * 
	 * @param customerID
	 * 			passes the customer's ID
	 * @param productID
	 * 			passes the product's ID
	 * @param rating
	 * 			passes the rating
	 * @param review
	 * 			passes the review
	 */
	public Review(int customerID, int productID, int rating, String review) throws IllegalArgumentException, NullPointerException {
		super();
		if (customerID<0||productID<0||rating<0) {
			throw new IllegalArgumentException("Cannot be less than 0");
		}
		if (review==null) {
			throw new NullPointerException("Cannot be left empty");
		}
		this.customerID = customerID;
		this.productID = productID;
		this.rating = rating;
		this.review = review;
	}

	/**
	 * Parameterised constructor 
	 * 
	 * @param productID
	 * 		 id is used to initialise the rest of the fields by querying the database
	 */
	public Review(int productID) throws IllegalArgumentException {
		super();
		if (productID<0) {
			throw new IllegalArgumentException("Cannot be less than 0!");
		}
		this.productID = productID;
		initialise();
	}
	
	/**
	 * The product id is used to retrieve data and initialise the other fields 
	 */
	public void initialise() {
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = null;
		try {
			query = "SELECT User.User_ID, Username, Rating, Review FROM Customer_Product_Reviews INNER JOIN"
					+ " User ON Customer_Product_Reviews.User_ID=User.User_ID WHERE Product_ID=?";
			
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getProductID());
			rs = pst.executeQuery();
			this.customerID = rs.getInt("User_ID");
			this.username = rs.getString("Username");
			this.rating = rs.getInt("Rating");
			this.review = rs.getString("Review");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}	
	}
	
	
	/**
	 * @returns the customerID
	 */
	public int getCustomerID() {
		return this.customerID;
	}

	/**
	 * @returns the username
	 */
	public String getUsername() {
		return this.username;
	}

	/**
	 * @returns the product id
	 */
	public int getProductID() {
		return this.productID;
	}

	/**
	 * @returns the rating of the review
	 */
	public int getRating() {
		return this.rating;
	}

	/**
	 * @returns the review text
	 */
	public String getReview() {
		return this.review;
	}


}
