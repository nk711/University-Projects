/**
 * AddNewProductTest.java
 */
package com.marketgui.test.nk00374;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.GroupType;
import com.marketgui.nk00374.AddNewProduct;
/**
 * @author Nithesh Koneswaran
 *
 */
public class AddNewProductTest {

	/**
	 * sets up the database before the actual object creation test
	 */
	@Before
	public void setUp() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;

		try {
			query = "INSERT INTO User VALUES (999, ?, ?, ?, ?, ?, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setString(1, "Nithesh");
			pst.setString(2, "Koneswaran");
			pst.setString(3, "nk00374");
			pst.setString(4, "test12345");
			pst.setString(5, "07/11/1998");
			pst.setString(6, "nk00374@surrey.ac.uk");
			pst.setString(7, "02084758387");
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

		try {
			query = "INSERT INTO Customer VALUES (999, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setDouble(1, 1000.0);
			pst.setString(2, GroupType.UNBANNED.toString());
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

	}

	/**
	 * Tears down the database
	 */
	@After
	public void tearDown() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;
		
		try {
			query = "DELETE FROM User WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Customer WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

	}

	
	/**
	 * Testing the constructor of the addNewProductTest
	 */
	@Test
	public void testConstructor() {
		CurrentSession session = CurrentSession.getInstance();
		session.logout();
		session.setUser(999);
		AddNewProduct addNewProduct = AddNewProduct.getObj();
	}
	
	/*
	 * Logging the user out and then testing the constructor of the addNewProductTest
	 * Should be NullPointerException since there is no one logged in
	 */
	@Test(expected = NullPointerException.class)
	public void testInvalidConstructor() {
		CurrentSession session = CurrentSession.getInstance();
		session.logout();
		AddNewProduct addNewProduct = AddNewProduct.getObj();
	}

}
