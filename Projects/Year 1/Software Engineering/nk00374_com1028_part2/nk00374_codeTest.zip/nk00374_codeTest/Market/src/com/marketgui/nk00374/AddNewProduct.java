/**
 * AddNewProduct.java
 */
package com.marketgui.nk00374;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.connection.nk00374.DBConnection;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Button;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import com.connection.nk00374.DBConnection;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.ProductCategory;
/**
 * 
 * Adding new product form.
 * 
 * @author Nithesh Koneswaran
 *
 */
public class AddNewProduct extends JFrame {
	private JPanel contentPane;
	/** user will input product title */
	private JTextField txtTitle;
	/** user will input  product details */
	private JTextField txtDetails;
	/** user will input product stock */
	private JTextField txtStock;
	/** user will input product cost */
	private JTextField txtCost;
	/** defines the restriction of  the product*/
	private JComboBox cbRestriction; 
	/** defines the category of the product */
	private JComboBox cbCategory ;
	/** The current logged in customer */
	private Customer customer;
	/** Error messaging */
	private StringBuffer emessage;
	/** Regex */
	private final static String MONEY = "[0-9]+([.]{1}[0-9]{0,2})|[0-9]+";
	private final static String NUMBERS = "\\d+";

	/** The instance of the object */
	private static AddNewProduct obj = null;
	
	/** Returns the instance of the object, this code will prevent another form from being opened again if it is already opened */
	public static AddNewProduct getObj() {
		if (obj==null) {
			obj = new AddNewProduct();
		} else {
			obj.dispose();
			obj = new AddNewProduct();
		}
		return obj;
	}
	
	/** Private constructor */
	private AddNewProduct() throws NullPointerException {
		/** gets the current logged in customer */
		this.customer = CurrentSession.getInstance().getCustomer();
		
		if (this.customer==null) {
			throw new NullPointerException("Customer cannot be null!");
		}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 370, 426);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(Color.BLACK);
		panel.setBackground(new Color(40, 50, 64));
		panel.setBounds(0, 0, 605, 53);
		this.contentPane.add(panel);
		
		JLabel lblUploadAProduct = new JLabel("Add your product");
		lblUploadAProduct.setForeground(new Color(222, 209, 63));
		lblUploadAProduct.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblUploadAProduct.setBackground(Color.WHITE);
		lblUploadAProduct.setBounds(21, 11, 232, 31);
		panel.add(lblUploadAProduct);
		
		this.txtTitle = new JTextField();
		this.txtTitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtTitle.setColumns(10);
		this.txtTitle.setBounds(10, 85, 334, 25);
		this.contentPane.add(this.txtTitle);
		
		JLabel lblProductTitle = new JLabel("Title");
		lblProductTitle.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblProductTitle.setBounds(10, 63, 123, 22);
		this.contentPane.add(lblProductTitle);
		
		JLabel lblDetails = new JLabel("Details");
		lblDetails.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblDetails.setBounds(10, 230, 123, 22);
		this.contentPane.add(lblDetails);
		
		this.txtDetails = new JTextField();
		this.txtDetails.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtDetails.setColumns(10);
		this.txtDetails.setBounds(10, 254, 334, 80);
		this.contentPane.add(this.txtDetails);
		
		JLabel lblStock = new JLabel("Stock");
		lblStock.setHorizontalAlignment(SwingConstants.CENTER);
		lblStock.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblStock.setBounds(10, 113, 99, 25);
		this.contentPane.add(lblStock);
		
		this.	txtStock = new JTextField();
		this.txtStock.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtStock.setColumns(10);
		this.txtStock.setBounds(12, 140, 97, 25);
		this.contentPane.add(this.txtStock);
		
		JLabel lblCost = new JLabel("Cost");
		lblCost.setHorizontalAlignment(SwingConstants.CENTER);
		lblCost.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblCost.setBounds(119, 108, 103, 34);
		this.contentPane.add(lblCost);
		
		this.txtCost = new JTextField();
		this.txtCost.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtCost.setColumns(10);
		this.	txtCost.setBounds(119, 140, 103, 25);
		this.contentPane.add(this.txtCost);
		
		JLabel lblAgeRestriction = new JLabel("Age Restriction");
		lblAgeRestriction.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblAgeRestriction.setBounds(233, 114, 111, 22);
		this.contentPane.add(lblAgeRestriction);
		
		this.cbRestriction = new JComboBox();
		this.cbRestriction.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.cbRestriction.setModel(new DefaultComboBoxModel(new String[] {"None", "18+", "21+"}));
		this.cbRestriction.setBounds(232, 140, 112, 25);
		this.	contentPane.add(this.cbRestriction);
		
		this.cbCategory = new JComboBox();
		this.cbCategory.setModel(new DefaultComboBoxModel(ProductCategory.values()));
		this.cbCategory.removeItemAt(0);
		this.cbCategory.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.cbCategory.setBounds(10, 194, 334, 25);
		this.contentPane.add(this.cbCategory);
		
		JLabel lblCategory = new JLabel("Category");
		lblCategory.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblCategory.setBounds(10, 169, 111, 22);
		this.contentPane.add(lblCategory);
		
		/** When the user presses the add button 
		 * the input are validated and checked before adding the product
		 * if the validation fails an error message pops up*/
		JButton btnSubmit = new JButton("Add");
		btnSubmit.setBounds(10, 345, 334, 29);
		this.contentPane.add(btnSubmit);
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (validation()) {
					addProduct();
				} else {
					JOptionPane.showMessageDialog(null, emessage.toString());
				}
			}
		});
		btnSubmit.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				dispose();
			}

		});
		
	}
	
	/**
	 * Validation
	 * @return true if the inputs are as expected, false otherwise
	 */
	public boolean validation() {
		this.emessage = new StringBuffer("Failed to add product: \n");
		boolean valid = true;
		if (this.txtTitle.getText().isEmpty() ||this. txtStock.getText().isEmpty() || this.txtCost.getText().isEmpty() || this.txtDetails.getText().isEmpty() ) {
			this.emessage.append("Please fill any blank fields \n");
			valid = false;
		}

		if (!this.txtCost.getText().matches(MONEY)) {
			this.emessage.append("invalid price \n");
			valid = false;
		}
		
		if (!this.txtStock.getText().matches(NUMBERS)) {
			this.emessage.append("invalid stock \n");
			valid = false;
		}	

			return valid;
	}

	
	/** method that adds the product to the database */
	public void addProduct() {
		Connection connect = DBConnection.connect();
		boolean errors = false;
		int age = 0;
		
		if (this.cbRestriction.getSelectedIndex()==0) {
			age = 0;
		}
		if (this.cbRestriction.getSelectedIndex()==1) {
			age = 18;
		}
		if (this.cbRestriction.getSelectedIndex()==2) {
			age = 21;
		}
		String query = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			query = "INSERT INTO Product VALUES (null, ?, ?, ?, ?, ?, ?, 0, ?)";
			pst = connect.prepareStatement(query);
			pst.setString(1, this.txtTitle.getText());
			pst.setString(2, this.txtDetails.getText());
			pst.setInt(3, Integer.parseInt(this.txtStock.getText()));
			pst.setInt(4, Integer.parseInt(this.txtStock.getText()));
			pst.setDouble(5, Double.parseDouble(this.txtCost.getText()));
			pst.setInt(6, age);
			pst.setString(7, this.cbCategory.getSelectedItem().toString());
			pst.executeUpdate();
		} catch (Exception e) {
			errors = true;
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					errors = true;
					e.printStackTrace();
				}
			}
		}
		
		
		try {
			query = "INSERT INTO Customer_Registered_Product VALUES (?, (SELECT last_insert_rowid()))";
			pst = connect.prepareStatement(query);
			pst.setInt(1, this.customer.getUserID());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "Product added, It must be checked by an admin first!");
		} catch (Exception e) {
			errors = true;
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					errors = true;
					e.printStackTrace();
				}
			}
		}
		
		
		if (errors) {
			JOptionPane.showMessageDialog(null, "Error Occured");
		}  else {
			this.customer.initialise();
			MyProductsForm.getObj().setVisible(true);
			dispose();
		}
		
		
	}
	
}
