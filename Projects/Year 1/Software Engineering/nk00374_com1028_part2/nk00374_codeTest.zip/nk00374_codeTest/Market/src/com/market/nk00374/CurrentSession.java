/**
 * CurrentSession.java
 */
package com.market.nk00374;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import com.connection.nk00374.DBConnection;

/**
 * This is a singleton class which will be defined once the user logs in. Once
 * the user logs in the class will be instantiated holding behaviour and
 * attributes of either an admin or customer
 * 
 * @author Nithesh Koneswaran
 */
public class CurrentSession {
	/** field holds the current instance of the object */
	private static CurrentSession instance = null;
	/** holds the customer that has logged in */
	private Customer customer;
	/** holds the admin that has logged in */
	private Admin admin;

	/**
	 * Default constructor
	 */
	private CurrentSession() {
	}

	/**
	 * @returns the current instance of the object
	 */
	public static CurrentSession getInstance() {
		if (instance == null) {
			instance = new CurrentSession();
		}
		return instance;
	}

	/**
	 * 
	 * @param id
	 *            The id of the user that had just logged in
	 *
	 * @returns true if the user logged in was an admin false if the user logged in
	 *          was a
	 */
	public boolean setUser(int id) throws IllegalArgumentException {
		if (id<0) {
			throw new IllegalArgumentException("Id cannot be less than 0");
		}
		boolean result = false;
		if (isAdmin(id)) {
			this.admin = new Admin(id);
			result = true;
		} else {
			this.customer = new Customer(id);
		}
		return result;
	}

	/**
	 * @returns the customer that has logged in
	 */
	public Customer getCustomer() {
		if (this.customer != null) {
			return this.customer;
		}
		return null;
	}

	/**
	 * 
	 * @returns the Admin that has logged in
	 */
	public Admin getAdmin() {
		if (this.admin != null) {
			return this.admin;
		}
		return null;
	}

	/**
	 * logs the user out
	 */
	public void logout() {
		this.customer = null;
		this.admin = null;
	}

	/**
	 * @param userId
	 * 			the userId of the user who had just logged in
	 * @returns true if the userID is an admin, false if else
	 */
	public static boolean isAdmin(int userId) throws IllegalArgumentException{
		if (userId<0) {
			throw new IllegalArgumentException("Id cannot be less than 0");
		}
		boolean result = false;
		Connection connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			final String query = "SELECT * FROM Administrator WHERE User_ID=?";
			pst = connect.prepareStatement(query);
			pst.setInt(1, userId);
			rs = pst.executeQuery();
			int counter = 0;
			while (rs.next()) {
				counter++;
			}
			if (counter == 1) {
				result = true;
			} else {
				result = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}

}
