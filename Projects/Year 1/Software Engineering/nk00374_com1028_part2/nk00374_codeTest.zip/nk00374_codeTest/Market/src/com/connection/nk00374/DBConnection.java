/**
 * DBConnection.java
 */
package com.connection.nk00374;
import java.sql.*;
import javax.swing.*;
/**
 * 
 * This static class will establish a connection to the database
 * 
 * @author Nithesh Koneswaran
 *
 */
public class DBConnection {

	/** This field will provide the connection to the database*/
	Connection connect = null;
	
	/**
	 * @returns opens a connection to the software's database
	 */
	public static Connection connect()  {
		try {
			Class.forName("org.sqlite.JDBC");
			Connection connect =  DriverManager.getConnection("jdbc:sqlite:database.db");
			return connect;
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			e.printStackTrace();
			return null;
		}
	} 
	
}