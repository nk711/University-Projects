/**
 * CustomerProfile.java
 */
package com.marketgui.nk00374;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
/**
 * @author Nithesh Koneswaran
 *
 */
public class CustomerProfile extends JFrame {
	private JPanel contentPane;
	/** The current logged in customer */
	private Customer customer;
	/** The instance of the CustomerProfile frame */
	private static CustomerProfile obj = null;
	/** Allows the user to update their balance in this field */
	private JTextField txtUpdateBalance;
	/** Regex for money*/
	private final static String MONEY = "[0-9]+([.]{1}[0-9]{0,2})|[0-9]+";
	
	/**
	 * @returns an instance of the form if it does not exist already
	 */
	public static CustomerProfile getObj() {
		if (obj==null) {
			obj = new CustomerProfile();
		} else {
			obj.dispose();
			obj = new CustomerProfile();
		}
		return obj;
	}
	
	
	/**
	 * Create the frame.
	 */
	public CustomerProfile() throws NullPointerException {
		this.customer = CurrentSession.getInstance().getCustomer();
		if (this.customer==null) {
			throw new NullPointerException("Customer cannot be null!");
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 348, 320);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(Color.BLACK);
		panel.setBackground(new Color(40, 50, 64));
		panel.setBounds(0, 0, 458, 53);
		this.contentPane.add(panel);
		
		JLabel lblYourProfile = new JLabel("Your Account");
		lblYourProfile.setForeground(new Color(222, 209, 63));
		lblYourProfile.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblYourProfile.setBackground(Color.WHITE);
		lblYourProfile.setBounds(21, 11, 191, 31);
		panel.add(lblYourProfile);
		
		JLabel lblUsername = new JLabel("Username :");
		lblUsername.setForeground(Color.BLACK);
		lblUsername.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblUsername.setBackground(Color.WHITE);
		lblUsername.setBounds(10, 64, 83, 22);
		this.contentPane.add(lblUsername);
		
		JLabel lblFullname = new JLabel("Fullname :");
		lblFullname.setForeground(Color.BLACK);
		lblFullname.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblFullname.setBackground(Color.WHITE);
		lblFullname.setBounds(10, 92, 83, 22);
		this.contentPane.add(lblFullname);
		
		JLabel lblBirthday = new JLabel("Birthday :");
		lblBirthday.setForeground(Color.BLACK);
		lblBirthday.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblBirthday.setBackground(Color.WHITE);
		lblBirthday.setBounds(10, 120, 57, 22);
		this.contentPane.add(lblBirthday);
		
		JLabel lblTelephone = new JLabel("Telephone :");
		lblTelephone.setForeground(Color.BLACK);
		lblTelephone.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblTelephone.setBackground(Color.WHITE);
		lblTelephone.setBounds(10, 149, 83, 22);
		this.contentPane.add(lblTelephone);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setForeground(Color.BLACK);
		lblEmail.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblEmail.setBackground(Color.WHITE);
		lblEmail.setBounds(10, 176, 83, 22);
		this.contentPane.add(lblEmail);
		
		JLabel lblBalance = new JLabel("Balance :");
		lblBalance.setForeground(Color.BLACK);
		lblBalance.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblBalance.setBackground(Color.WHITE);
		lblBalance.setBounds(10, 209, 83, 22);
		this.contentPane.add(lblBalance);
		
		JLabel txtUsername = new JLabel("----");
		txtUsername.setText(this.customer.getUsername());
		txtUsername.setForeground(Color.BLACK);
		txtUsername.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		txtUsername.setBackground(Color.WHITE);
		txtUsername.setBounds(85, 64, 237, 22);
		this.contentPane.add(txtUsername);
		
		JLabel txtFullName = new JLabel("----");
		txtFullName.setText(this.customer.getFullName());
		txtFullName.setForeground(Color.BLACK);
		txtFullName.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		txtFullName.setBackground(Color.WHITE);
		txtFullName.setBounds(85, 92, 237, 22);
		this.contentPane.add(txtFullName);
		
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		JLabel txtBirthday = new JLabel("----");
		txtBirthday.setText(format.format(this.customer.getBirthday()));
		txtBirthday.setForeground(Color.BLACK);
		txtBirthday.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		txtBirthday.setBackground(Color.WHITE);
		txtBirthday.setBounds(68, 120, 136, 22);
		this.contentPane.add(txtBirthday);
		
		JLabel txtTelephone = new JLabel("----");
		txtTelephone.setText(this.customer.getTelephone());
		txtTelephone.setForeground(Color.BLACK);
		txtTelephone.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		txtTelephone.setBackground(Color.WHITE);
		txtTelephone.setBounds(85, 149, 237, 22);
		this.contentPane.add(txtTelephone);
		
		JLabel txtEmail = new JLabel("----");
		txtEmail.setText(this.customer.getEmail());
		txtEmail.setForeground(Color.BLACK);
		txtEmail.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		txtEmail.setBackground(Color.WHITE);
		txtEmail.setBounds(58, 176, 264, 22);
		this.contentPane.add(txtEmail);
		
		DecimalFormat currency = new DecimalFormat("#0.00");
		JLabel txtBalance = new JLabel("----"); 
		txtBalance.setText(String.valueOf("�"+currency.format((this.customer.getBalance()))));
		txtBalance.setForeground(Color.BLACK);
		txtBalance.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		txtBalance.setBackground(Color.WHITE);
		txtBalance.setBounds(85, 209, 83, 22);
		this.contentPane.add(txtBalance);
		
		/**
		 *  When the user presses the add button the user's balance
		 *  will be updated accordingly
		 */
		JButton btnUpdateBalance = new JButton("Add to balance");
		btnUpdateBalance.setEnabled(false);
		btnUpdateBalance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (txtUpdateBalance.getText().matches(MONEY)) {
					customer.addToBalance(Double.parseDouble(txtUpdateBalance.getText()));
					txtBalance.setText("�"+currency.format(customer.getBalance()));
				} else {
					JOptionPane.showMessageDialog(null, "Invalid field!");
				}
			}
		});
		btnUpdateBalance.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnUpdateBalance.setBounds(10, 242, 312, 29);
		this.contentPane.add(btnUpdateBalance);
		
		/**
		 *  Once the user has typed in a value into the textfield, only then can the user
		 *  press the add button.
		 */
		this.txtUpdateBalance = new JTextField();
		this.txtUpdateBalance.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void changedUpdate(DocumentEvent arg0) {
				check();
			}

			@Override
			public void insertUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				check();
			}

			@Override
			public void removeUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				check();
			}

			public void check() {
				if (txtUpdateBalance.getText().isEmpty()) {
					btnUpdateBalance.setEnabled(false);
				} else {
					btnUpdateBalance.setEnabled(true);
				}
			}
		});
		this.txtUpdateBalance.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		this.txtUpdateBalance.setColumns(10);
		this.txtUpdateBalance.setBounds(178, 210, 144, 25);
		this.contentPane.add(this.txtUpdateBalance);
		
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			 public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		        dispose();
		    }
			
		});
		
	}
}
