/**
 * ReviewTest.java
 */
package com.market.test.nk00374;
import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.GroupType;
import com.market.nk00374.ProductCategory;
import com.market.nk00374.Review;
/**
 * 
 * @author Nithesh Koneswaran
 *
 */
public class ReviewTest {

	/**
	 * sets up the database before the actual object creation test
	 * 
	 * Must insert user, customer, product data before adding Customer Product_Reviews
	 */
	@Before
	public void setUp() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;
		
		try {
			query = "INSERT INTO User VALUES (999, ?, ?, ?, ?, ?, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setString(1, "Nithesh");
			pst.setString(2, "Koneswaran");
			pst.setString(3, "nk00374");
			pst.setString(4, "test12345");
			pst.setString(5, "07/11/1998");
			pst.setString(6, "nk00374@surrey.ac.uk");
			pst.setString(7, "02084758387");
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

		try {
			query = "INSERT INTO Customer VALUES (999, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setDouble(1, 1000.0);
			pst.setString(2, GroupType.UNBANNED.toString());
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "INSERT INTO Product VALUES (999, ?, ?, ?, ?, ?, ?, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setString(1, "Product");
			pst.setString(2, "Very good product");
			pst.setInt(3, 23);
			pst.setInt(4, 23);
			pst.setDouble(5, 12.99);
			pst.setInt(6, 0);
			pst.setInt(7, 0);
			pst.setString(8, ProductCategory.CLOTHING.toString());
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "INSERT INTO Customer_Product_Reviews VALUES (999, 999, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setInt(1, 4);
			pst.setString(2, "Amazing product!!");
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
	}

	/**
	 * Tears down the database
	 */
	@After
	public void tearDown() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;
		
		try {
			query = "DELETE FROM User WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Customer WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Product WHERE Product_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Customer_Product_Reviews WHERE Product_ID=999 AND User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
	}

	/**
	 * Creates a Review object Checks a sample of methods to see if it returns
	 * correct values
	 */
	@Test
	public void testConstructor1() {
		Review review = new Review(999);
		assertEquals("Amazing product!!", review.getReview());
		assertEquals(4, review.getRating());

	}

	/**
	 * Creates a Review object Checks a sample of methods to see if it returns
	 * correct values
	 */
	@Test
	public void testConstructor2() {
		Review review = new Review(23,34,4,"Amazing product!!");
		assertEquals("Amazing product!!", review.getReview());
		assertEquals(4, review.getRating());
	}
	
	/**
	 * Creates a Review object and if an error is thrown in case of invalid id
	 */
	@Test(expected = NullPointerException.class)
	public void testInvalidConstructor1() {
		Review review = new Review(23,34,4,null);
		assertEquals("Amazing product!!", review.getReview());
		assertEquals(4, review.getRating());
	}
	
	/**
	 * Creates a Review object and if an error is thrown in case of invalid id
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidConstructor2() {
		Review review = new Review(23,-34,4,null);
		assertEquals("Amazing product!!", review.getReview());
		assertEquals(4, review.getRating());
	}
	
	/**
	 * Creates a Review object and if an error is thrown in case of invalid id
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidConstructor3() {
		Review review = new Review(-23,34,4,null);
		assertEquals("Amazing product!!", review.getReview());
		assertEquals(4, review.getRating());
	}
	
	/**
	 * Creates a Review object and if an error is thrown in case of invalid id
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidConstructor4() {
		Review review = new Review(-23);
		assertEquals("Amazing product!!", review.getReview());
		assertEquals(4, review.getRating());
	}

}
