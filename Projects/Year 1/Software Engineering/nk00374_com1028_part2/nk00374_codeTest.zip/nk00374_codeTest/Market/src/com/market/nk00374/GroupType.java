/**
 * GroupType.java
 */
package com.market.nk00374;  
/**
 * An Enumeration class that tags the user, which determines whether they are banned or not
 * 
 * @author Nithesh Koneswaran
 *
 */
public enum GroupType {
	UNBANNED, BANNED
}
