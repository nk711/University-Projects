/**
 * ProductType
 */
package com.market.nk00374;
/**
 * This class defines whether a product can be verified or non verified
 * @author Nithesh Koneswaran
 *
 */
public enum ProductType {
	VERIFIED, NONVERIFIED
}
