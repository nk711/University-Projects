/**
 * User.java
 */
package com.market.nk00374;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.connection.nk00374.DBConnection;
/**
 * This class holds the behaviour and attributes of a user
 * 
 * @author Nithesh Koneswaran
 */
public abstract class User {
	/** Holds the user's ID */
	private int userID = 0;
	/** Holds the user's firstname */
	private String firstName = null;
	/** Holds the user's surname */
	private String surname = null;
	/** Holds the user's username */
	private String username = null;
	/** Holds the user's password */
	private String password = null;
	/** Holds the user's birthday */
	private Date birthday = null;
	/** Holds the user's age */
	private int age = 0;
	/** Holds the user's telephone */
	private String telephone = null;
	/** Holds the user's email */
	private String email = null;
	/** allows the program to connect to the database */
	private Connection connect;

	/**
	 * Parameterised constructor
	 * 
	 * @param userID
	 *            The id of the user
	 */
	public User(int userID) throws IllegalArgumentException {
		super();
		if (userID<0) {
			throw new IllegalArgumentException("Cannot be less than 0");
		}
		this.userID = userID;
		this.setUp();
	}

	/**
	 * Initialises all the fields of the user object
	 */
	public void setUp() {
		connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = null;
		try {
			SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

			query = "SELECT * FROM User WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.userID);
			rs = pst.executeQuery();

			while (rs.next()) {
				this.firstName = rs.getString("First_Name");

				this.surname = rs.getString("Surname");

				this.birthday = format.parse(rs.getString("Birthday"));

				this.username = rs.getString("Username");

				int age = 0;
				Calendar now = Calendar.getInstance();
				Calendar dob = Calendar.getInstance();

				dob.setTime(birthday);
				age = now.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

				if (now.get(Calendar.MONTH) > dob.get(Calendar.MONTH)) {
					age -= 1;
				}

				if (now.get(Calendar.MONTH) == dob.get(Calendar.MONTH)) {
					if (now.get(Calendar.DAY_OF_MONTH) > dob.get(Calendar.DAY_OF_MONTH)) {
						age -= 1;
					}
				}
				this.age = age;
				this.telephone = rs.getString("Telephone");
				this.email = rs.getString("Email");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * @returns the user's full name
	 */
	public String getFullName() {
		return this.firstName + " " + this.surname;
	}

	/**
	 * @returns the user's id
	 */
	public int getUserID() {
		return this.userID;
	}


	/**
	 * @returns the user's first name
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * @param firstName
	 *            sets the user's first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @returns the user's surname
	 */
	public String getSurname() {
		return this.surname;
	}

	

	/**
	 * @returns the user's Username
	 */
	public String getUsername() {
		return this.username;
	}




	/**
	 * @returns the user's password
	 */
	public String getPassword() {
		return password;
	}


	/**
	 * @returns the user's birthday
	 */
	public Date getBirthday() {
		return birthday;
	}


	/**
	 * @returns the user's age
	 */
	public int getAge() {
		return age;
	}


	/**
	 * @returns the user's telephone
	 */
	public String getTelephone() {
		return telephone;
	}


	/**
	 * @returns the user's email
	 */
	public String getEmail() {
		return email;
	}



}
