/**
 * Customer.java
 */
package com.market.nk00374;

import com.connection.nk00374.DBConnection;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;

/**
 * This class defines the properties and begaviour of a user object
 * 
 * @author Nithesh Koneswaran
 *
 */
public class Customer extends User {
	/** Holds the balance of the user */
	private double balance = 0.0;
	/** Tags whether the user is banned or unbanned */
	private GroupType group = null;
	/** Holds the list of reviews made by the user */
	private List<Review> reviews = null;
	/** Holds the list of products in the user's basket */
	private Map<Integer, Integer> basket = null;
	/** Holds the list of wishlist in the user's wishlist */
	private List<Integer> wishList = null;
	/** Holds the list of transactions made by the user */
	private List<Transaction> transactions = null;
	/** Holds the list of registered product registered by the user */
	private List<Integer> registeredProducts = null;
	/** Provides a connection to the database */
	private Connection connect;

	/**
	 * Parameterised constructor to create customer object
	 * 
	 * @param userID
	 *            this will be passed into the user super class this will be used to
	 *            populate the other fields via SQL
	 */
	public Customer(int userID) throws IllegalArgumentException {
		super(userID);
		if (userID < 0) {
			throw new IllegalArgumentException("Id cannot be less than 0");
		}
		initialise();
	}

	/**
	 * This will populate the fields of the user using the customer's ID SQL is used
	 * to retrieve user information
	 */
	public void initialise() {
		this.balance = 0.0;
		this.group = null;
		this.reviews = new ArrayList<>();
		this.basket = new HashMap<>();
		this.wishList = new ArrayList<>();
		this.transactions = new ArrayList<>();
		this.registeredProducts = new ArrayList<>();

		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = null;
		try {
			query = "SELECT * FROM Customer WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getUserID());
			rs = pst.executeQuery();

			while (rs.next()) {
				this.balance = rs.getDouble("Balance");

				if (rs.getString("GroupType").equals(GroupType.BANNED.toString())) {
					this.group = GroupType.BANNED;
				}

				if (rs.getString("GroupType").equals(GroupType.UNBANNED.toString())) {
					this.group = GroupType.UNBANNED;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		try {
			query = "SELECT * FROM Customer_Basket WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getUserID());
			rs = pst.executeQuery();
			while (rs.next()) {
				this.basket.put(rs.getInt("Product_ID"), rs.getInt("Quantity"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		try {
			query = "SELECT * FROM Customer_Product_Reviews WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getUserID());
			rs = pst.executeQuery();
			while (rs.next()) {
				this.reviews.add(new Review(rs.getInt("Product_ID")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		try {
			query = "SELECT * FROM Customer_Registered_Product WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getUserID());
			rs = pst.executeQuery();
			while (rs.next()) {
				this.registeredProducts.add(rs.getInt("Product_ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		try {
			query = "SELECT * FROM Customer_Transactions WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getUserID());
			rs = pst.executeQuery();
			while (rs.next()) {
				/** not in the correct date form */

				this.transactions
						.add(new Transaction(rs.getInt("Product_ID"), rs.getString("Date"), rs.getInt("Quantity")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		try {
			query = "SELECT * FROM Customer_Wishlist WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getUserID());
			rs = pst.executeQuery();
			while (rs.next()) {
				this.wishList.add(rs.getInt("Product_ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Allows the user to change the quantity of items of a product in the user's
	 * basket
	 * 
	 * @param productID
	 *            The selected product
	 * @param quantity
	 *            The quantity change
	 */
	public void changeQuantityBasket(int productID, int quantity) throws IllegalArgumentException {
		if (productID < 0 || quantity < 0) {
			throw new IllegalArgumentException("Quantity/ProductID cannot be less than 0!");
		}
		Product product = new Product(productID);
		if (quantity < product.getStock()) {
			throw new IllegalArgumentException("Quantity/ProductID cannot be less than 0!");
		}

		basket.put(productID, quantity);
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		String query = null;
		try {
			query = "UPDATE Customer_Basket SET quantity=? WHERE User_ID=? AND Product_ID=?";
			pst = connect.prepareStatement(query);
			pst.setInt(1, this.basket.get(productID));
			pst.setInt(2, this.getUserID());
			pst.setInt(3, productID);
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Adds a product to the basket
	 * 
	 * @param productID
	 *            the product's ID of the product being added to the basket
	 * @param quantity
	 *            the quantity
	 */
	public void addToBasket(int productID, int quantity) throws IllegalArgumentException {
		if (productID < 0 || quantity < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		boolean exists = false;
		String query = null;
		if (this.basket.containsKey(productID)) {
			this.basket.put(productID, basket.get(productID) + quantity);
			exists = true;
		} else {
			this.basket.put(productID, quantity);
		}

		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		if (exists) {
			try {
				query = "UPDATE Customer_Basket SET quantity=? WHERE User_ID=? AND Product_ID=?";
				pst = this.connect.prepareStatement(query);
				pst.setInt(1, this.basket.get(productID));
				pst.setInt(2, this.getUserID());
				pst.setInt(3, productID);
				pst.executeUpdate();
				/** Closes database connection */

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

		} else {
			try {
				query = "INSERT INTO Customer_Basket VALUES (?,?,?)";
				pst = connect.prepareStatement(query);
				pst.setInt(1, this.getUserID());
				pst.setInt(2, productID);
				pst.setInt(3, this.basket.get(productID));
				pst.executeUpdate();
				/** Closes database connection */
				pst.close();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

		}

	}

	/**
	 * Checks whether the product exists in the user's basket
	 * 
	 * @param productID
	 *            the product id of the product
	 * @returns true if exists, false otherwise
	 */
	public boolean existsInBasket(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		return this.basket.containsKey(productID);
	}

	/**
	 * Removes an item in the user's basket
	 * 
	 * @param productID
	 *            The product ID of the product to be removed
	 */
	public void removeFromBasket(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		String query = null;
		if (existsInBasket(productID)) {
			this.connect = DBConnection.connect();
			PreparedStatement pst = null;
			try {
				query = "DELETE FROM Customer_Basket WHERE User_ID=? AND Product_ID=?";
				pst = this.connect.prepareStatement(query);
				pst.setInt(1, this.getUserID());
				pst.setInt(2, productID);
				pst.executeUpdate();
				this.basket.remove(productID);
				/** Closes database connection */
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	/**
	 * Clears the user's basket
	 */
	public void clearBasket() {
		String query = null;
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		try {
			query = "DELETE FROM Customer_Basket WHERE User_ID=?";
			pst = connect.prepareStatement(query);
			pst.setInt(1, this.getUserID());
			pst.executeUpdate();
			this.basket.clear();
			/** Closes database connection */
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * @returns the total cost of the user's basket
	 */
	public double getTotalCost() {
		double totalCost = 0.0;
		if (!this.basket.isEmpty()) {
			for (Product product : this.getBasket()) {
				double totalItem = product.getPrice() * this.getQuantity(product.getProductID());
				totalCost += totalItem;
			}
		}
		return totalCost;
	}

	/**
	 * Allows the user to purchase their basket
	 * 
	 * @returns true if the purchase was successfull, otherwise false
	 */
	public boolean buyBasket() {
		boolean result = true;
		double total = this.getTotalCost();
		if (this.balance < total) {
			JOptionPane.showMessageDialog(null, "Not enough balance");
			result = false;
		} else {
			double balanceLeft = this.balance - total;
			if (balanceLeft >= 0) {
				updateProductStock();
				this.setBalance(balanceLeft);
				this.setTransactions();
				this.clearBasket();
			}
		}
		return result;
	}

	/** Updates the product's stock after the user has purchased an item */
	public void updateProductStock() {
		for (Product product : this.getBasket()) {
			product.setStock(product.getStock() - this.getQuantity(product.getProductID()));
			;
		}
	}

	/**
	 * Creates a transaction after the user has purchased an item
	 */
	public void setTransactions() {

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

		for (Map.Entry<Integer, Integer> item : this.basket.entrySet()) {
			this.connect = DBConnection.connect();
			PreparedStatement pst = null;
			try {
				String query = "INSERT INTO Customer_Transactions VALUES (?,?,?,?)";
				pst = this.connect.prepareStatement(query);
				pst.setInt(1, this.getUserID());
				pst.setInt(2, item.getKey());
				pst.setString(3, format.format(new Date()));
				pst.setInt(4, item.getValue());
				pst.executeUpdate();
				this.transactions.add(new Transaction(item.getKey(), format.format(new Date()), item.getValue()));
				/** Closes database connection */
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}

	}

	/**
	 * Checks if a product exists in the Wish list
	 * 
	 * @param productID
	 *            The product ID of the product in the wishlist
	 * @returns true if the product exists in the wishlist, else false
	 */
	public boolean existInWishlist(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		return this.wishList.contains(productID);
	}

	/**
	 * Adds a product to the wishlist
	 * 
	 * @param productID
	 *            The product ID of the product to be added in to the wishlist
	 */
	public void addToWishlist(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		String query = null;
		if (!existInWishlist(productID)) {
			this.wishList.add(productID);
			this.connect = DBConnection.connect();
			PreparedStatement pst = null;

			try {
				query = "INSERT INTO Customer_Wishlist VALUES (?,?)";
				pst = this.connect.prepareStatement(query);
				pst.setInt(1, this.getUserID());
				pst.setInt(2, productID);
				pst.executeUpdate();
				/** Closes database connection */
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

		}
	}

	/**
	 * @param productID
	 *            The product ID of the product to be removed from the wishlist
	 */
	public void removeFromWishlist(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}

		String query = null;
		if (existInWishlist(productID)) {
			this.connect = DBConnection.connect();
			PreparedStatement pst = null;
			try {
				query = "DELETE FROM Customer_Wishlist WHERE User_ID=? AND Product_ID=?";
				pst = connect.prepareStatement(query);
				pst.setInt(1, this.getUserID());
				pst.setInt(2, productID);
				pst.executeUpdate();
				/** Closes database connection */
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			this.wishList.remove((Integer) productID);

		}
	}

	/**
	 * Checks if the user has already created a review for the selected product
	 * 
	 * @param productID
	 * @returns true if the user has already created a list of u
	 */
	public boolean existInReview(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		boolean exists = false;
		for (Review review : this.reviews) {
			if (review.getProductID() == productID) {
				exists = true;
			}
		}
		return exists;
	}

	/**
	 * Adds a review to the user's review list
	 * 
	 * @param review
	 *            The review object to be added to the list
	 * @returns true if process was successful
	 */
	public boolean addToReviewList(Review review) throws NullPointerException {
		if (review == null) {
			throw new NullPointerException("cannot be less than 0!");
		}
		Boolean errors = false;
		if (!reviews.contains(review)) {
			this.connect = DBConnection.connect();
			PreparedStatement pst = null;
			ResultSet rs = null;
			try {
				String query = "INSERT INTO Customer_Product_Reviews VALUES (?,?,?,?)";
				pst = this.connect.prepareStatement(query);
				pst.setInt(1, this.getUserID());
				pst.setInt(2, review.getProductID());
				pst.setInt(3, review.getRating());
				pst.setString(4, review.getReview());
				pst.executeUpdate();
				/** Closes database connection */
			} catch (Exception e) {
				errors = true;
				e.printStackTrace();
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (Exception e) {
						errors = true;
						e.printStackTrace();
					}
				}
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						errors = true;
						e.printStackTrace();
					}
				}

			}
		} else {
			errors = true;
		}
		if (!errors) {
			this.reviews.add(review);
		}
		return errors;
	}

	/**
	 * deletes a review of a product
	 * 
	 * @param productID
	 *            the user's review of the product will be deleted
	 */
	public void deleteReview(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		boolean errors = false;
		int index = 0;
		for (int i = 0; i < this.reviews.size(); i++) {
			if (this.reviews.get(i).getProductID() == productID) {
				index = i;
				this.connect = DBConnection.connect();
				PreparedStatement pst = null;
				try {
					String query = "DELETE FROM Customer_Product_Reviews WHERE User_ID=? AND Product_ID=?";
					pst = this.connect.prepareStatement(query);
					pst.setInt(1, this.getUserID());
					pst.setInt(2, productID);
					pst.executeUpdate();
					/** Closes database connection */
				} catch (Exception e) {
					errors = true;
					e.printStackTrace();
				} finally {
					if (pst != null) {
						try {
							pst.close();
						} catch (Exception e) {
							errors = true;
							e.printStackTrace();
						}
					}
				}
			}
		}

		if (!errors) {
			this.reviews.remove(index);
		}
	}

	/**
	 * @returns the user's balance
	 */
	public double getBalance() {
		return this.balance;
	}

	/**
	 * @param productID,
	 *            the product id of the product in the user's basket
	 * @returns the quantity of a product in the user's basket
	 */
	public int getQuantity(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}

		return this.basket.get(productID);
	}

	/**
	 * @returns the user's basket
	 */
	public List<Product> getBasket() {
		List<Product> newBasket = new ArrayList<Product>();
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			final String query = "SELECT Product.Product_ID, Product.Name, Product.Current_Stock, Product.Cost FROM Product INNER JOIN Customer_Basket ON Product.Product_ID=Customer_Basket.Product_ID WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1, this.getUserID());
			rs = pst.executeQuery();
			while (rs.next()) {
				Product product = new Product(rs.getInt("Product_ID"), rs.getString("Name"), rs.getInt("Current_Stock"),
						rs.getDouble("Cost"));
				newBasket.add(product);
			}
		} catch (Exception a) {
			a.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return newBasket;
	}

	/**
	 * @returns the user's wishlist
	 */
	public List<Product> getWishlist() {
		List<Product> newWishList = new ArrayList<Product>();
		if (!this.wishList.isEmpty()) {
			for (Integer id : this.wishList) {
				newWishList.add(new Product(id));
			}
		}
		return newWishList;
	}




	/**
	 * @returns the user's list of transactions
	 */
	public List<Transaction> getTransactions() {
		return this.transactions;
	}



	/**
	 * @returns the user's list of registered products
	 */
	public List<Product> getRegisteredProducts() {
		ArrayList<Product> products = new ArrayList<Product>();
		for (int id : this.registeredProducts) {
			products.add(new Product(id));
		}
		return products;
	}

	/**
	 * @param ProductID
	 *            Adds newly registered product to the registered product list
	 */
	public void AddNewRegisteredProduct(int productID) throws IllegalArgumentException {
		if (productID < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}

		this.registeredProducts.add(productID);
	}


	/**
	 * @param balance
	 *            sets the user's balance with the new price
	 */
	public void setBalance(double balance) throws IllegalArgumentException {
		if (balance < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		if (balance >= 0) {
			this.connect = DBConnection.connect();
			String query = null;
			PreparedStatement pst = null;
			try {
				query = "UPDATE Customer SET Balance=? WHERE User_ID=?";
				pst = this.connect.prepareStatement(query);
				pst.setDouble(1, balance);
				pst.setInt(2, super.getUserID());
				pst.executeUpdate();
				this.balance = balance;
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	/**
	 * @param balance
	 *            adds balance on top of the user's balance
	 */
	public void addToBalance(double balance) throws IllegalArgumentException {
		if (balance < 0) {
			throw new IllegalArgumentException("cannot be less than 0!");
		}
		if (balance >= 0) {
			this.connect = DBConnection.connect();
			String query = null;
			PreparedStatement pst = null;
			try {
				this.balance = this.balance + balance;
				query = "UPDATE Customer SET Balance=? WHERE User_ID=?";
				pst = this.connect.prepareStatement(query);
				pst.setDouble(1, this.balance);
				pst.setInt(2, super.getUserID());
				pst.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (pst != null) {
					try {
						pst.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}

	}

	/**
	 * @returns whether the user is tagged banned or unbanned
	 */
	public GroupType getGroup() {
		return this.group;
	}

	/**
	 * @param group
	 *            sets the user's group
	 */
	public void setGroup(GroupType group) throws NullPointerException {
		if (group == null) {
			throw new NullPointerException("Cannot be left blank!");
		}

		this.connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;
		try {
			query = "UPDATE Customer SET GroupType=? WHERE User_ID=?";
			pst = this.connect.prepareStatement(query);
			pst.setString(1, group.toString());
			pst.setInt(2, super.getUserID());
			pst.executeUpdate();
			this.group = group;
		} catch (Exception e) {
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {

					e.printStackTrace();
				}
			}
		}
	}

}
