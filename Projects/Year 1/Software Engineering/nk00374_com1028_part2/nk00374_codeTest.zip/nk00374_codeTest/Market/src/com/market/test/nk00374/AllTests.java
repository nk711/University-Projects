/**
 * AllTests.java
 */
package com.market.test.nk00374;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 *  Runs all the tests
 *  @author Nithesh Koneswaran
 */

@RunWith(Suite.class)
@SuiteClasses({ AdminTest.class,  CurrentSessionTest.class,
	CustomerTest.class, ProductTest.class, ReviewTest.class, TransactionTest.class, UserTest.class})
public class AllTests {
}