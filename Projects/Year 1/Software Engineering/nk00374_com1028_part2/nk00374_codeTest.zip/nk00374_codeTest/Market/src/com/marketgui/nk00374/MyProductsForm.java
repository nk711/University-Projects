/**
 * MyProductsForm.java
 */
package com.marketgui.nk00374;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.Product;
import com.market.nk00374.Review;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.SystemColor;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
/**
 * @author Nithesh Koneswaran
 *
 */
public class MyProductsForm extends JFrame {

	private JPanel contentPane;
	/** Formats the product's price */
	private DecimalFormat currency;
	/** Formats the product's id */
	private DecimalFormat id;
	/** The currently logged in customer */
	private Customer customer;
	/** displays the list of registered products */
	private JList<String> list;
	/** holds the list of registered products */
	private List<Product> registeredProducts;
	/** holds a product's list of reviews */
	private JTextArea txtReviews;
	/** holds how many product has been sold */
	private JLabel txtSold;
	/** category of a selected product */
	private JLabel txtCategory;
	/** displays whether a selected product is verified or non verified */
	private JLabel txtVerified;
	/** displays the price of a selected product */
	private JLabel txtPrice;
	/** displays the stock of a selected product */
	private JLabel txtStock;
	/** displays the rating of a selected product */
	private JLabel txtRating;
	/** displays any restriction of a selected product */
	private JLabel txtAge;
	/** displays the product title of a selected product */
	private JLabel txtProductTitle;
	/** displays the product description of a selected product */
	private JTextArea txtDetails;

	/** sets the instance of the product form to null*/
	private static MyProductsForm obj = null;
	/**
	 * @param productID
	 * 			This will be the product the user will be editing
	 * @returns the instance of the product form if it does not exist already
	 */
	public static MyProductsForm getObj() {
		if (obj == null) {
			obj = new MyProductsForm();
		} else {
			obj.dispose();
			obj = new MyProductsForm();
		}
		return obj;
	}

	/**
	 * Create the frame.
	 */
	private MyProductsForm() throws NullPointerException {
		this.id = new DecimalFormat("#0000");
		this.currency = new DecimalFormat("#0.00");
		this.customer = CurrentSession.getInstance().getCustomer();
		if (this.customer == null) {
			throw new NullPointerException("Customer cannot be empty!");
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 701, 552);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(Color.BLACK);
		panel.setBackground(new Color(40, 50, 64));
		panel.setBounds(0, 0, 685, 57);
		this.contentPane.add(panel);

		JLabel lblMyProducts = new JLabel("My Products");
		lblMyProducts.setForeground(new Color(222, 209, 63));
		lblMyProducts.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblMyProducts.setBackground(Color.WHITE);
		lblMyProducts.setBounds(21, 11, 233, 31);
		panel.add(lblMyProducts);

		/**
		 * User can press the add product button to add a new product
		 */
		JButton btnAddNewProduct = new JButton("Add");
		btnAddNewProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddNewProduct.getObj().setVisible(true);
			}
		});

		btnAddNewProduct.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnAddNewProduct.setBounds(394, 11, 87, 29);
		panel.add(btnAddNewProduct);

		/**
		 *  An edit form will pop up upon on click of the edit button
		 *  only if a product is selected from the JList
		 */
		JButton btnChange = new JButton("Edit");
		btnChange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (list.getSelectedIndex() != -1) {
					String[] parts = list.getSelectedValue().split(" \\| ");
					int id = Integer.parseInt(parts[0]);
					EditProduct.getObj(id).setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "Select a product to be edited!");
				}
			}
		});
		btnChange.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnChange.setBounds(491, 11, 87, 29);
		panel.add(btnChange);

		/**
		 *  When the user presses the remove button the product is removed from the database
		 */
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (list.getSelectedIndex() != -1) {
					int selectedOption = JOptionPane.showConfirmDialog(null, "Do you want to remove Product?", "",
							JOptionPane.YES_NO_OPTION);
					if (selectedOption == JOptionPane.YES_OPTION) {
						String[] parts = list.getSelectedValue().split(" \\| ");
						int id = Integer.parseInt(parts[0]);
						for (Product product : registeredProducts) {
							if (product.getProductID() == id) {
								if (product.deleteProduct()) {
									customer.initialise();
									loadUsersProducts();
								}
							}
						}
					}
				} else {
					JOptionPane.showMessageDialog(null, "Select a product to be edited!");
				}
			}
		});

		btnRemove.setBounds(588, 11, 87, 29);
		panel.add(btnRemove);
		btnRemove.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));

		this.list = new JList<String>();
		this.list.setSelectedIndex(0);
		this.list.setLayoutOrientation(JList.VERTICAL_WRAP);
		this.list.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.list.setBackground(SystemColor.menu);
		this.list.setBounds(10, 64, 231, 438);
		this.contentPane.add(list);

		/**
		 * When a product is selected in the JList, its details are displayed on to JLabels
		 */
		this.list.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				if (list.getSelectedIndex() != -1) {
					String[] parts = list.getSelectedValue().split(" \\| ");
					int id = Integer.parseInt(parts[0]);
					Product selected = null;
					for (Product product : registeredProducts) {
						if (product.getProductID() == id) {
							selected = product;
						}
					}

					StringBuffer list = new StringBuffer();
					List<Review> ratings = new ArrayList<>();
					ratings = selected.getReviews();
					double average = 0.0;
					int counter = 0;

					if (!ratings.isEmpty()) {
						for (Review review : ratings) {
							list.append(review.getReview() + "\n");
							list.append("By " + review.getUsername());
							list.append("  [Rating: " + review.getRating() + "]\n\n");
							average += review.getRating();
							counter++;
						}
						txtRating.setText(String.valueOf(average / counter + "/5"));
						txtReviews.setText(list.toString());
					} else {
						txtRating.setText("N/A");
						txtReviews.setText("N/A");
					}

					if (selected.getAgeRestriction() == 0) {
						txtAge.setText("None");
					}
					if (selected.getAgeRestriction() == 1) {
						txtAge.setText("18+");
					}
					if (selected.getAgeRestriction() == 2) {
						txtAge.setText("21+");
					}

					txtProductTitle.setText(selected.getTitle());
					txtVerified.setText(selected.getType().toString());
					txtStock.setText(String.valueOf(selected.getStock()));
					txtCategory.setText(selected.getCategory().toString());
					txtPrice.setText("�" + String.valueOf(selected.getPrice()));
					txtSold.setText(String.valueOf(selected.getSold()));
					txtDetails.setText(selected.getDescription());

				}

			}
		});

		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBackground(new Color(40, 50, 64));
		separator.setBounds(251, 65, 9, 437);
		this.contentPane.add(separator);

		this.txtProductTitle = new JLabel("Product Title");
		this.txtProductTitle.setForeground(Color.BLACK);
		this.txtProductTitle.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		this.txtProductTitle.setBackground(Color.WHITE);
		this.txtProductTitle.setBounds(262, 53, 340, 48);
		this.contentPane.add(this.txtProductTitle);

		JLabel label = new JLabel("Price  :");
		label.setForeground(Color.BLACK);
		label.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		label.setBackground(Color.WHITE);
		label.setBounds(270, 112, 55, 22);
		this.contentPane.add(label);

		JLabel label_1 = new JLabel("Stock  :");
		label_1.setForeground(Color.BLACK);
		label_1.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		label_1.setBackground(Color.WHITE);
		label_1.setBounds(270, 136, 55, 22);
		this.contentPane.add(label_1);

		JLabel label_3 = new JLabel("Reviews:");
		label_3.setForeground(Color.BLACK);
		label_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		label_3.setBackground(Color.WHITE);
		label_3.setBounds(270, 341, 104, 22);
		this.contentPane.add(label_3);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBackground(new Color(40, 50, 64));
		separator_1.setBounds(270, 368, 409, 8);
		this.contentPane.add(separator_1);

		this.txtReviews = new JTextArea();
		this.txtReviews.setLineWrap(true);
		this.txtReviews.setForeground(Color.BLACK);
		this.txtReviews.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtReviews.setEditable(false);
		this.txtReviews.setBackground(SystemColor.menu);
		this.txtReviews.setBounds(270, 379, 405, 123);
		this.contentPane.add(this.txtReviews);

		JSeparator separator_2 = new JSeparator();
		separator_2.setBackground(new Color(40, 50, 64));
		separator_2.setBounds(273, 210, 406, 8);
		this.contentPane.add(separator_2);

		JLabel lblDetails = new JLabel("Details");
		lblDetails.setForeground(Color.BLACK);
		lblDetails.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblDetails.setBackground(Color.WHITE);
		lblDetails.setBounds(270, 180, 104, 22);
		this.contentPane.add(lblDetails);

		this.txtDetails = new JTextArea();
		this.txtDetails.setLineWrap(true);
		this.txtDetails.setForeground(Color.BLACK);
		this.txtDetails.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtDetails.setEditable(false);
		this.txtDetails.setBackground(SystemColor.menu);
		this.txtDetails.setBounds(270, 220, 405, 124);
		this.contentPane.add(this.txtDetails);

		JLabel label_4 = new JLabel("Rating :");
		label_4.setForeground(Color.BLACK);
		label_4.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		label_4.setBackground(Color.WHITE);
		label_4.setBounds(515, 136, 55, 22);
		this.contentPane.add(label_4);

		this.txtVerified = new JLabel("-----");
		this.txtVerified.setForeground(Color.BLACK);
		this.txtVerified.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtVerified.setBackground(Color.WHITE);
		this.txtVerified.setBounds(270, 90, 152, 22);
		this.contentPane.add(this.txtVerified);

		this.txtPrice = new JLabel("\u00A3--.--");
		this.txtPrice.setForeground(Color.BLACK);
		this.txtPrice.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtPrice.setBackground(Color.WHITE);
		this.txtPrice.setBounds(325, 112, 97, 22);
		this.contentPane.add(this.txtPrice);

		this.txtStock = new JLabel("----");
		this.txtStock.setForeground(Color.BLACK);
		this.txtStock.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtStock.setBackground(Color.WHITE);
		this.txtStock.setBounds(325, 136, 97, 22);
		this.contentPane.add(this.txtStock);

		this.txtRating = new JLabel("-");
		this.txtRating.setForeground(Color.BLACK);
		this.txtRating.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtRating.setBackground(Color.WHITE);
		this.txtRating.setBounds(564, 136, 121, 22);
		this.contentPane.add(this.txtRating);

		JLabel lblAgeRestriction = new JLabel("Age Restriction:");
		lblAgeRestriction.setForeground(Color.BLACK);
		lblAgeRestriction.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblAgeRestriction.setBackground(Color.WHITE);
		lblAgeRestriction.setBounds(515, 90, 97, 22);
		this.contentPane.add(lblAgeRestriction);

		this.txtAge = new JLabel("---");
		this.txtAge.setForeground(Color.BLACK);
		this.txtAge.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtAge.setBackground(Color.WHITE);
		this.txtAge.setBounds(615, 90, 60, 22);
		this.contentPane.add(this.txtAge);

		JLabel lblSold = new JLabel("Sold: ");
		lblSold.setForeground(Color.BLACK);
		lblSold.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblSold.setBackground(Color.WHITE);
		lblSold.setBounds(515, 112, 97, 22);
		this.contentPane.add(lblSold);

		JLabel lblCategory = new JLabel("Category: ");
		lblCategory.setForeground(Color.BLACK);
		lblCategory.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblCategory.setBackground(Color.WHITE);
		lblCategory.setBounds(270, 158, 69, 22);
		this.contentPane.add(lblCategory);

		this.txtSold = new JLabel("--");
		this.txtSold.setForeground(Color.BLACK);
		this.txtSold.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtSold.setBackground(Color.WHITE);
		this.txtSold.setBounds(548, 112, 127, 22);
		this.contentPane.add(this.txtSold);

		this.txtCategory = new JLabel("-----");
		this.txtCategory.setForeground(Color.BLACK);
		this.txtCategory.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.txtCategory.setBackground(Color.WHITE);
		this.txtCategory.setBounds(339, 158, 103, 22);
		this.contentPane.add(this.txtCategory);

		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				dispose();
			}

		});

		loadUsersProducts();
	}

	/**
	 * Loads the list of products that are registered by the currently logged in user 
	 */
	public void loadUsersProducts() {
		this.registeredProducts = this.customer.getRegisteredProducts();
		DefaultListModel<String> listModel = new DefaultListModel<String>();
		if (!this.registeredProducts.isEmpty()) {
			this.list.removeAll();
			for (Product product : this.registeredProducts) {
				listModel.addElement(this.id.format(product.getProductID()) + " | " + product.getTitle() + " | �"
						+ this.currency.format(product.getPrice()));
			}
		} 
		this.list.setModel(listModel);
	}
}
