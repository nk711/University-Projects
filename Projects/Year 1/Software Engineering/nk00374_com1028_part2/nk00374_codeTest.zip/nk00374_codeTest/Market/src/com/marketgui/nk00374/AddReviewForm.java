/**
 * AddReviewForm.java
 */
package com.marketgui.nk00374;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.Review;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.sql.*;
/**
 * 
 * @author Nithesh Koneswaran
 * 
 */
public class AddReviewForm extends JFrame {

	private JPanel contentPane;
	/** Input field to enter rating */
	private JTextField txtRating;
	/** Provides a connection to the database*/
	private Connection connect = null;
	/** The current logged in customer */
	private Customer customer = null;
	/** Regex */
	private final static String RATING = "[0-5]|-[1-5]";
	
	/** The instance of the object */
	private static AddReviewForm obj = null;
	
	/** 
	 * @returns the instance of the basket form if an instance does not exists already
	 */
	public static AddReviewForm getObj(int productID) {
		if (obj==null) {
			obj = new AddReviewForm(productID);
		} 
		return obj; 
	}
	
	
	 
	
	/**
	 * Create the frame.
	 */
	private AddReviewForm(int productID) throws IllegalArgumentException, NullPointerException {
		/** Gets the current logged in user */
		this.customer = CurrentSession.getInstance().getCustomer();
		if (this.customer==null) {
			throw new NullPointerException("Customer cannot be left empty!");
		}
		
		if (productID<0) {
			throw new IllegalArgumentException("ID cannot be less than 0!");
		}
	
		setBounds(100, 100, 358, 285);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.	contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(40,50,63));
		panel.setBounds(0, 0, 342, 60);
		this.contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblAddAReview = new JLabel("Add a review");
		lblAddAReview.setBounds(10, 11, 309, 34);
		lblAddAReview.setForeground(new Color(222, 209, 63));
		lblAddAReview.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblAddAReview.setBackground(Color.WHITE);
		panel.add(lblAddAReview);
		
		JLabel label = new JLabel("Rating :");
		label.setForeground(Color.BLACK);
		label.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		label.setBackground(Color.WHITE);
		label.setBounds(10, 213, 55, 22);
		this.contentPane.add(label);
		
		this.	txtRating = new JTextField();
		this.txtRating.setToolTipText("");
		this.txtRating.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.	txtRating.setColumns(10);
		this.	txtRating.setBounds(65, 213, 22, 23);
		this.	contentPane.add(this.txtRating);
		
		JTextArea txtReview = new JTextArea();
		txtReview.setLineWrap(true);
		txtReview.setForeground(Color.BLACK);
		txtReview.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		txtReview.setEditable(true);
		txtReview.setBackground(Color.WHITE);
		txtReview.setBounds(10, 71, 322, 131);
		this.contentPane.add(txtReview);
		
		/**
		 * When the user presses the add a review button, the input fields are validated and the new review is added to the database
		 */
		JButton btnAdd = new JButton("Add a Review");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Boolean errors = false;
				if (txtRating.getText().matches(RATING)&&!txtReview.getText().isEmpty()) {
					Review review = new Review(customer.getUserID(),productID, 
							Integer.parseInt(txtRating.getText()),txtReview.getText());
					errors = customer.addToReviewList(review);
				} else {
					JOptionPane.showMessageDialog(null, "Fill in the appropriate fields!");
					errors = true;
				}	
				
				if (!errors) {
					dispose();
				}	
			}	
		});
		
		
		btnAdd.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnAdd.setBounds(129, 211, 203, 29);
		this.contentPane.add(btnAdd);
		
		JLabel label_1 = new JLabel("/5");
		label_1.setForeground(Color.BLACK);
		label_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		label_1.setBackground(Color.WHITE);
		label_1.setBounds(97, 213, 22, 22);
		this.contentPane.add(label_1);
		
		
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			 public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		        dispose();
		    }
			
		});
		
	}


}
