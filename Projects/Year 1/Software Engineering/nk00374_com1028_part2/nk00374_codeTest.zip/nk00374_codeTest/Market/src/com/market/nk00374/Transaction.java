/**
 * Transaction.java
 */
package com.market.nk00374;
import java.util.Date;
/**
 * This class defines the behaviour and attributes of a transaction object 
 * 
 * @author Nithesh Koneswaran
 *
 */
public class Transaction {
	/** The product that has been bought by the user */
	private int productID = 0;
	/** The date of purchase */
	private String date = null;
	/** The quantity purchased */
	private int quantity = 0;
	
	/**
	 * Parameterised constructor 
	 * 
	 * @param productID
	 * 		The product purchased
	 * @param date
	 * 		The date of purchase
	 * @param quantity
	 * 		The quantity of purchase
	 */
	public Transaction(int productID, String date, int quantity) throws IllegalArgumentException, NullPointerException {
		super();
		if (productID<0||quantity<0) {
			throw new IllegalArgumentException("Cannot be less than 0!");
		}
		if (date == null) {
			throw new NullPointerException("Cannot be left empty!");
		}
		this.productID = productID;
		this.date = date;
		this.quantity = quantity;
	
	}

	/**
	 * @returns the date of purchase
	 */
	public String getDate() {
		return this.date;
	}
	/**
	 * @returns the product's ID
	 */
	public int getProductID() {
		return this.productID;
	}
	/**
	 * @returns the quantity purchased 
	 */
	public int getQuantity() {
		return this.quantity;
	}

	
}
