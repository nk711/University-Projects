/**
 * Admin.java
 */
package com.market.nk00374;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import com.connection.nk00374.DBConnection;
/**
 * This class defines the properties and behaviour of an admin
 * 
 * @author Nithesh Koneswaran
 *
 */
public class Admin extends User {

	/** this field will provide a connection to the database */
	private Connection connect;

	/**
	 * Constructor for an admin
	 * @param id
	 * 		passes id into the super class (User)
	 */
	public Admin(int id) throws  IllegalArgumentException {
		super(id);
		if (id<0) {
			throw new IllegalArgumentException("Id cannot be less than 0");
		}
	}
	
	/**
	 * @returns a list of logs
	 */
	public String loadLogs() {
		StringBuffer log = new StringBuffer("Log \n");
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = null;
		try {
			query = "SELECT * FROM log";
			pst = this.connect.prepareStatement(query);
			rs = pst.executeQuery();

			while (rs.next()) {
				log.append(rs.getString("Date")+"\n");
				log.append(rs.getString("Action")+"\n");
				log.append("ID: " + rs.getString("User_ID"));
				log.append("\n\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		return log.toString();
	}
	
	/**
	 * @param action
	 *			adds the action to the list of logs
	 */
	public void addLog(String action) throws NullPointerException {
		if (action==null) {
			throw new NullPointerException("Action cannot be left null!");
		}
		this.connect = DBConnection.connect();
		PreparedStatement pst = null;
		String query = null;
		try {
			query = "INSERT INTO log VALUES (?,?,?)";
			pst = this.connect.prepareStatement(query);
			pst.setInt(1,super.getUserID());
			pst.setString(2, action);
			pst.setString(3, new Date().toString());
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
}