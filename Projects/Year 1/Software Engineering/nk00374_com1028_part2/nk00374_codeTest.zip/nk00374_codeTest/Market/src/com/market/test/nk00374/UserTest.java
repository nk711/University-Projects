/**
 * UserTest.java
 */
package com.market.test.nk00374;

import static org.junit.Assert.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.connection.nk00374.DBConnection;
import com.market.nk00374.Customer;

/**
 * 
 * @author Nithesh Koneswaran
 *
 */
public class UserTest {

	/**
	 * sets up the database before the actual object creation test
	 */
	@Before
	public void setUp() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;
		try {
			query = "INSERT INTO User VALUES (999, ?, ?, ?, ?, ?, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setString(1, "Nithesh");
			pst.setString(2, "Koneswaran");
			pst.setString(3, "nk00374");
			pst.setString(4, "test12345");
			pst.setString(5, "07/11/1998");
			pst.setString(6, "nk00374@surrey.ac.uk");
			pst.setString(7, "02084758387");
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
	}

	/**
	 * Tears down the database
	 */
	@After
	public void tearDown() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;

		try {
			query = "DELETE FROM User WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
	}

	/**
	 * Creating an user object
	 */
	@Test
	public void testConstructor() {
		Customer user = new Customer(999);
		assertEquals("Nithesh Koneswaran", user.getFullName());
		assertEquals("02084758387", user.getTelephone());
		assertEquals("nk00374@surrey.ac.uk", user.getEmail());
		assertEquals("nk00374", user.getUsername());
	}

	/**
	 * Testing the creation of a user object using invalid parameters
	 * 
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidConstructor() {
		Customer user = new Customer(-23);
		assertEquals("Nithesh Koneswaran", user.getFullName());
		assertEquals("02084758387", user.getTelephone());
		assertEquals("nk00374@surrey.ac.uk", user.getEmail());
		assertEquals("nk00374", user.getUsername());
	}
}
