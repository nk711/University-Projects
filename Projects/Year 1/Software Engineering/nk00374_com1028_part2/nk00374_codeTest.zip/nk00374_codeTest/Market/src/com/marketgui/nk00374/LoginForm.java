/**
 * LoginForm.java
 */
package com.marketgui.nk00374;

import java.awt.EventQueue;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.Admin;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.GroupType;
import com.market.nk00374.User;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.Window.Type;
import java.awt.Button;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.swing.*;
/**
 * @author Nithesh Koneswaran
 *
 */
public class LoginForm {
	private JFrame frame;
	/** Input for the password to log in */
	private JPasswordField txtPassword;
	/** Input for the username to log in */
	private JTextField txtUsername;
	/** Provides a connection to the database */
	private Connection connect = null;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginForm window = new LoginForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginForm() {
		initialize();
		this.frame.setVisible(true);
		this.connect = DBConnection.connect();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		/** Creates an instance of the singleton class */
		CurrentSession currentSession = CurrentSession.getInstance();
		this.frame = new JFrame();
		this.frame.getContentPane().setBackground(UIManager.getColor("Button.background"));
		this.frame.getContentPane().setForeground(Color.WHITE);
		this.frame.setBounds(100, 100, 353, 249);
		this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.frame.getContentPane().setLayout(null);

		this.txtPassword = new JPasswordField();
		this.txtPassword.setColumns(10);
		this.txtPassword.setBounds(10, 128, 317, 25);
		this.frame.getContentPane().add(this.txtPassword);

		JLabel lblUsername = new JLabel("Username ");
		lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblUsername.setBounds(10, 59, 83, 22);
		this.frame.getContentPane().add(lblUsername);

		JLabel lblPassword = new JLabel("Password  ");
		lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblPassword.setBounds(10, 105, 131, 22);
		this.	frame.getContentPane().add(lblPassword);

		this.txtUsername = new JTextField();
		this.txtUsername.setColumns(10);
		this.txtUsername.setBounds(10, 81, 317, 25);
		this.frame.getContentPane().add(this.txtUsername);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(40, 50, 63));
		panel.setBounds(0, -3, 342, 60);
		this.frame.getContentPane().add(panel);

		JLabel lblLogInOr = new JLabel("LOG IN or ");
		lblLogInOr.setForeground(new Color(222, 209, 63));
		lblLogInOr.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblLogInOr.setBackground(Color.WHITE);
		lblLogInOr.setBounds(10, 11, 119, 34);
		panel.add(lblLogInOr);

		JLabel lblRegister = new JLabel("REGISTER");
		lblRegister.setForeground(Color.WHITE);
		lblRegister.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblRegister.setBackground(Color.WHITE);
		lblRegister.setBounds(130, 11, 119, 34);
		panel.add(lblRegister);

		/**
		 * When the user presses the login button, the code access the database and sees
		 * whether an account exists matching the username and password input
		 * If it does exists then it checks whether the account is banned or not.
		 * If the user is unbanned then the main page/admin page is loaded
		 */
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				connect = DBConnection.connect();
				PreparedStatement pst = null;
				ResultSet rs = null;
				try {
					final String query = "SELECT * FROM user WHERE username=? AND password=?";
					pst = connect.prepareStatement(query);
					pst.setString(1, txtUsername.getText());
					pst.setString(2, hash(new String(txtPassword.getPassword())));

					/** fetches the result */
					rs = pst.executeQuery();
					/**
					 * There should be only one row, otherwise the password or username is incorrect
					 */
					int counter = 0;
					while (rs.next()) {
						counter++;
					}
					rs.close();
					if (counter == 1) {
						int age = 0;
						rs = pst.executeQuery();
						SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
						Date birthday = format.parse(rs.getString("Birthday"));
						Calendar now = Calendar.getInstance();
						Calendar dob = Calendar.getInstance();

						dob.setTime(birthday);
						age = now.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
						if (now.get(Calendar.MONTH) > dob.get(Calendar.MONTH)) {
							age -= 1;
						}
						if (now.get(Calendar.MONTH) == dob.get(Calendar.MONTH)) {
							if (now.get(Calendar.DAY_OF_MONTH) > dob.get(Calendar.DAY_OF_MONTH)) {
								age -= 1;
							}
						}

						if (currentSession.setUser(rs.getInt("User_ID"))) {
							AdminMainForm centre = new AdminMainForm();
							centre.setVisible(true);
							frame.dispose();
						} else {
							Customer customer = new Customer(rs.getInt("User_ID"));
							if (customer.getGroup().equals(GroupType.BANNED)) {
								JOptionPane.showMessageDialog(null,
										"You have been banned!!\nThe Ban Hammer has spoken");
							} else {
								MainPage mainPage = new MainPage();
								mainPage.setVisible(true);
								frame.dispose();
							}
						}

					} else {
						JOptionPane.showMessageDialog(null, "Unsuccessfull Login");
					}
					/** Closes database connection */

				} catch (Exception exception) {
					JOptionPane.showMessageDialog(null, exception);
					exception.printStackTrace();

				} finally {
					if (rs != null) {
						try {
							rs.close();
						} catch (Exception exception) {
							exception.printStackTrace();
						}
					}
					if (pst != null) {
						try {
							pst.close();
						} catch (Exception exception) {
							exception.printStackTrace();
						}
					}
				}

			}
		});

		btnLogin.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnLogin.setEnabled(true);
		btnLogin.setBounds(10, 164, 187, 29);
		this.frame.getContentPane().add(btnLogin);

		/**
		 * When the user presses the register button, the register form will pop up
		 */
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterForm register = new RegisterForm();
				register.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnRegister.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		btnRegister.setEnabled(true);
		btnRegister.setBounds(207, 164, 120, 29);
		this.frame.getContentPane().add(btnRegister);

	}

	/**
	 * Security method, hashes the password so no one can see the actual password in the database
	 * @param password
	 * 			the password to be hashed
	 * @returns the hashed value of the password
	 */
	public String hash(String password) {
		String pass;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(password.getBytes());
			pass = new String(md.digest());
			return pass;
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
	}
}
