/**
 * LoginFormTest.java
 */
package com.marketgui.test.nk00374;

import static org.junit.Assert.*;

import org.junit.Test;

import com.market.nk00374.CurrentSession;
import com.marketgui.nk00374.EditProduct;
import com.marketgui.nk00374.LoginForm;
/**
 * @author Nithesh Koneswaran
 *
 */
public class LoginFormTest {

	/**
	 * Testing the constructor of the Login form
	 */
	@Test
	public void testConstructor() {
		LoginForm login = new LoginForm();
	}
	
	/**
	 * There are no other cases
	 */
}
