/**
 * RegisterFormTest.java
 */
package com.marketgui.test.nk00374;
import org.junit.Test;
import com.marketgui.nk00374.RegisterForm;
/**
 * @author Nithesh Koneswaran
 *
 */
public class RegisterFormTest {
	
	/**
	 * Testing the constructor of the RegisterForm
	 */
	@Test
	public void testConstructor() {
		RegisterForm register = new RegisterForm();
	}
	

	/**
	 * No other cases
	 */
}
