/**
 * BasketForm.java
 */
package com.marketgui.nk00374;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.CurrentSession;
import com.market.nk00374.Customer;
import com.market.nk00374.Product;

import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.SystemColor;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * @author Nithesh Koneswaran
 *
 */
public class BasketForm extends JFrame {

	private JPanel contentPane;
	/** allows the user to select a quantity */
	private JTextField txtQuantity;
	/** holds the quantity of the product*/
	private JLabel lblCurrentProductQuantity;
	/** Formats the price of the product */
	private DecimalFormat currency;
	/** Formats the id of the product */
	private DecimalFormat id;
	/** Displays the list of products in the user's basket */
	private JList<String> basketList;
	/** The total price of the basket */
	private JLabel lblVariableTotal;
	/** holds user's balance */
	private JLabel lblVariableBalance;
	/** holds the selected quantity of the selected product */
	private JLabel lblVariableQuantity;
	/** displays the remaining stock of a product*/
	private JLabel lblVariableStock;
	/** Holds the list of products in the user's basket */
	private List<Product> basket;
	/** Purchases all items in the basket upon click */
	private JButton btnBuyNow;
	/** removes an item from the basket upon click */
	private JButton btnRemoveFromBasket;
	/** Changes the quantity of an item in the basket upon click */
	private JButton btnChangeQuantity;
	/** The product id of the selected item */
	private int productID;
	/** The customer that is currently logged in */
	private Customer customer;

	/** Instance of the BasketForm */
	private static BasketForm obj = null;

	/** 
	 * @returns the instance of the basket form if an instance does not exists already
	 */
	public static BasketForm getObj() {
		if (obj == null) {
			obj = new BasketForm();
		} else {
			obj.dispose();
			obj = new BasketForm();
		}
		return obj;
	}

	/**
	 * Create the frame.
	 */
	private BasketForm() throws NullPointerException {
		this.customer = CurrentSession.getInstance().getCustomer();
		if (this.customer==null) {
			throw new NullPointerException("Customer cannot be null!");
		}
		this.basket = new ArrayList<Product>();
		this.id = new DecimalFormat("#0000");
		this.currency = new DecimalFormat("#0.00");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 340);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(Color.BLACK);
		panel.setBackground(new Color(40, 50, 64));
		panel.setBounds(0, 0, 485, 53);
		this.contentPane.add(panel);

		JLabel lblMyBasket = new JLabel("My Basket");
		lblMyBasket.setForeground(new Color(222, 209, 63));
		lblMyBasket.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		lblMyBasket.setBackground(Color.WHITE);
		lblMyBasket.setBounds(21, 11, 116, 31);
		panel.add(lblMyBasket);

		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBackground(new Color(40, 50, 64));
		separator.setBounds(252, 64, 9, 223);
		this.contentPane.add(separator);

		this.basketList = new JList<String>();
		this.basketList.setSelectedIndex(0);
		this.basketList.setLayoutOrientation(JList.VERTICAL_WRAP);
		this.basketList.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.basketList.setBackground(SystemColor.menu);
		this.basketList.setBounds(10, 60, 232, 227);
		this.contentPane.add(basketList);

		/**
		 * When the user press the buy now button.... 
		 * Validation is in place to ensure the basket is not empty and that the user has enough money
		 */
		this.btnBuyNow = new JButton("Buy Now");
		this.btnBuyNow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (basket.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Basket is empty");
				} else {
					if (customer.buyBasket()) {
						lblVariableBalance.setText("�" + String.valueOf(currency.format(customer.getBalance())));
						loadBasket();
						lblVariableStock.setText("0");
						lblVariableQuantity.setText("0");
					} else {
						JOptionPane.showMessageDialog(null, "Failed transaction");
					}
				}
				
				if (basketList.getSelectedIndex() == -1) {
					btnRemoveFromBasket.setEnabled(false);
					btnChangeQuantity.setEnabled(false);

				} else {
					btnRemoveFromBasket.setEnabled(true);
				}
			}
		});
		this.btnBuyNow.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		this.btnBuyNow.setEnabled(true);
		this.btnBuyNow.setBounds(271, 258, 204, 29);
		this.contentPane.add(this.btnBuyNow);

		/**
		 * When the user presses the remove button
		 * The selected product in the JList will be removed
		 */
		this.btnRemoveFromBasket = new JButton("Remove from basket");
		this.btnRemoveFromBasket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int selectedOption = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove this product?",
						"", JOptionPane.YES_NO_OPTION);
				if (selectedOption == JOptionPane.YES_OPTION) {
					customer.removeFromBasket(productID);
					loadBasket();
					getInfo();
					lblVariableQuantity.setText("0");
					lblVariableStock.setText("0");
				}
				
				if (basketList.getSelectedIndex() == -1) {
					btnRemoveFromBasket.setEnabled(false);
					btnChangeQuantity.setEnabled(false);

				} else {
					btnRemoveFromBasket.setEnabled(true);
				}
				
			}
		});
		this.	btnRemoveFromBasket.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		this.	btnRemoveFromBasket.setEnabled(false);
		this.btnRemoveFromBasket.setBounds(271, 218, 204, 29);
		this.contentPane.add(this.btnRemoveFromBasket);

		/**
		 * When the user presses the change quantity button
		 * the quantity of the selected item in the Jlist will change to the value in the textfield.
		 * The textfield is validated.
		 */
		this.btnChangeQuantity = new JButton("Change Quantity To");
		this.btnChangeQuantity.setEnabled(false);
		this.btnChangeQuantity.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int quantity = Integer.parseInt(txtQuantity.getText());
				int stock = new Product(productID).getStock();

				if (quantity > 0 && quantity <= stock) {
					customer.changeQuantityBasket(productID, quantity);
					lblVariableQuantity.setText(String.valueOf(quantity));
					loadBasket();
					getInfo();
				} else {
					JOptionPane.showMessageDialog(null, "Invalid Input");
				}
				
				if (basketList.getSelectedIndex() == -1) {
					btnRemoveFromBasket.setEnabled(false);
					btnChangeQuantity.setEnabled(false);

				} else {
					btnRemoveFromBasket.setEnabled(true);
				}
				
				
			}
		});

		this.btnChangeQuantity.setFont(new Font("Segoe UI Light", Font.PLAIN, 14));
		this.btnChangeQuantity.setEnabled(true);
		this.btnChangeQuantity.setBounds(321, 178, 155, 29);
		this.contentPane.add(this.btnChangeQuantity);

		/**
		 * This is validation check to ensure that the user cannot selected the change quantity button until the user has entered a value into the textfield
		 */
		this.txtQuantity = new JTextField();
		this.txtQuantity.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void changedUpdate(DocumentEvent arg0) {
				check();
			}

			@Override
			public void insertUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				check();
			}

			@Override
			public void removeUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				check();
			}

			public void check() {
				if (txtQuantity.getText().isEmpty()) {
					btnChangeQuantity.setEnabled(false);
				} else {
					btnChangeQuantity.setEnabled(true);
				}
			}
		});
		this.txtQuantity.setToolTipText("");
		this.txtQuantity.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		this.	txtQuantity.setColumns(10);
		this.txtQuantity.setBounds(271, 177, 40, 29);
		this.contentPane.add(this.txtQuantity);

		JLabel lblTotalCost = new JLabel("Total Cost :");
		lblTotalCost.setForeground(Color.BLACK);
		lblTotalCost.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblTotalCost.setBackground(Color.WHITE);
		lblTotalCost.setBounds(271, 60, 83, 22);
		this.contentPane.add(lblTotalCost);

		this.lblCurrentProductQuantity = new JLabel("Selected Quantity :");
		this.lblCurrentProductQuantity.setForeground(Color.BLACK);
		this.lblCurrentProductQuantity.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.lblCurrentProductQuantity.setBackground(Color.WHITE);
		this.lblCurrentProductQuantity.setBounds(271, 144, 178, 22);
		this.contentPane.add(this.lblCurrentProductQuantity);

		JLabel lblYourBalance = new JLabel("Your balance :");
		lblYourBalance.setForeground(Color.BLACK);
		lblYourBalance.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblYourBalance.setBackground(Color.WHITE);
		lblYourBalance.setBounds(271, 88, 97, 22);
		this.contentPane.add(lblYourBalance);

		this.lblVariableTotal = new JLabel("0");
		this.lblVariableTotal.setForeground(Color.BLACK);
		this.lblVariableTotal.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.lblVariableTotal.setBackground(Color.WHITE);
		this.	lblVariableTotal.setBounds(343, 60, 132, 22);
		this.	contentPane.add(this.lblVariableTotal);

		this.lblVariableBalance = new JLabel("0");
		this.lblVariableBalance.setForeground(Color.BLACK);
		this.lblVariableBalance.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.lblVariableBalance.setBackground(Color.WHITE);
		this.lblVariableBalance.setBounds(363, 88, 112, 22);
		this.contentPane.add(this.lblVariableBalance);

		this.lblVariableQuantity = new JLabel("0");
		this.lblVariableQuantity.setForeground(Color.BLACK);
		this.lblVariableQuantity.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.lblVariableQuantity.setBackground(Color.WHITE);
		this.lblVariableQuantity.setBounds(392, 144, 83, 22);
		this.contentPane.add(this.lblVariableQuantity);

		JLabel lblRemainingStock = new JLabel("Remaining Stock   :");
		lblRemainingStock.setForeground(Color.BLACK);
		lblRemainingStock.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		lblRemainingStock.setBackground(Color.WHITE);
		lblRemainingStock.setBounds(271, 116, 178, 22);
		this.contentPane.add(lblRemainingStock);

		this.lblVariableStock = new JLabel("0");
		this.lblVariableStock.setForeground(Color.BLACK);
		this.lblVariableStock.setFont(new Font("Segoe UI Light", Font.PLAIN, 15));
		this.lblVariableStock.setBackground(Color.WHITE);
		this.lblVariableStock.setBounds(392, 116, 83, 22);
		this.contentPane.add(this.lblVariableStock);

		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				dispose();
			}
		});

		loadBasket();
		this.basketList.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				getInfo();
				if (basketList.getSelectedIndex() != -1) {
					btnRemoveFromBasket.setEnabled(true);
				}
			}
		});

		this.lblVariableBalance.setText("�" + String.valueOf(currency.format(customer.getBalance())));
	}

	/**
	 * Gets the information of an item that is selected in the list
	 */
	public void getInfo() {
		this.btnChangeQuantity.setEnabled(false);
		this.txtQuantity.setText(null);
		if (this.basketList.getSelectedIndex() != -1) {
			String[] parts = this.basketList.getSelectedValue().split(" \\| ");
			this.productID = Integer.parseInt(parts[0]);
			this.lblVariableQuantity.setText(String.valueOf(this.customer.getQuantity(this.productID)));
			for (Product product : this.basket) {
				if (product.getProductID() == this.productID) {
					this.lblVariableStock.setText(String.valueOf(product.getStock()));
				}
			}
			this.lblVariableBalance.setText("�" + String.valueOf(this.currency.format(this.customer.getBalance())));
		}

		if (this.txtQuantity.getText().isEmpty()) {

		}
	}

	/**
	 * Loads the user's basket into the Jlist 
	 */
	public void loadBasket() {
		List<Product> getBasket = new ArrayList<Product>();
		DefaultListModel<String> list = new DefaultListModel<String>();
		getBasket = this.customer.getBasket();

		for (Product product : getBasket) {
			this.basket.add(product);
			list.addElement(this.id.format(product.getProductID()) + " | " + product.getTitle() + " | �"
					+ this.currency.format(product.getPrice()));

		}
		this.basketList.setModel(list);
		this.lblVariableTotal.setText("�" + String.valueOf(this.currency.format(this.customer.getTotalCost())));

	}

}
