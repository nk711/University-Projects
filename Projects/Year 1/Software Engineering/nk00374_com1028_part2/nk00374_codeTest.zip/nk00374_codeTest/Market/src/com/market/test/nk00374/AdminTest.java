/**
 * AdminTest.java
 */
package com.market.test.nk00374;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.connection.nk00374.DBConnection;
import com.market.nk00374.Admin;

/**
 * Tests the Admin class
 * 
 * @author Nithesh Koneswaran
 *
 */
public class AdminTest {

	/**
	 * sets up the database before the actual object creation test
	 */
	@Before
	public void setUp() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;

		try {
			query = "INSERT INTO User VALUES (999, ?, ?, ?, ?, ?, ?, ?)";
			pst = connect.prepareStatement(query);
			pst.setString(1, "Nithesh");
			pst.setString(2, "Koneswaran");
			pst.setString(3, "nk00374");
			pst.setString(4, "test12345");
			pst.setString(5, "07/11/1998");
			pst.setString(6, "nk00374@surrey.ac.uk");
			pst.setString(7, "02084758387");
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

		try {
			query = "INSERT INTO Administrator VALUES (null, 999)";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

	}

	/**
	 * Tears down the database
	 */
	@After
	public void tearDown() throws Exception {
		Connection connect = DBConnection.connect();
		String query = null;
		PreparedStatement pst = null;
		
		try {
			query = "DELETE FROM User WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}
		
		try {
			query = "DELETE FROM Administrator WHERE User_ID=999";
			pst = connect.prepareStatement(query);
			pst.executeUpdate();
		} catch (Exception error) {
			error.printStackTrace();
		} finally {
			if (pst != null) {
				try {
					pst.close();
				} catch (Exception error) {
					error.printStackTrace();
				}
			}
		}

	}

	/**
	 * Creates an admin objects Checks a sample of methods to see if it returns
	 * correct values
	 */
	@Test
	public void testAdminCreation() {
		Admin admin = new Admin(999);
		assertEquals("Nithesh Koneswaran", admin.getFullName());
		assertEquals("02084758387", admin.getTelephone());
		assertEquals("nk00374@surrey.ac.uk", admin.getEmail());
		assertEquals("nk00374", admin.getUsername());
	}

	/**
	 * Creating an Admin object and check error is thrown in case of invalid admin
	 * id
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidConstructor() {
		Admin admin = new Admin(-23);
	}

}
